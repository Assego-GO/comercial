<?php
// Debug do Importador CSV - Para identificar problemas na Hostgator
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/debug_import.log');

// Configurações básicas
ini_set('max_execution_time', 300); // 5 minutos para teste
ini_set('memory_limit', '256M');

header('Content-Type: text/plain; charset=utf-8');
header('Cache-Control: no-cache');

function debugLog($message, $level = 'INFO') {
    $timestamp = date('Y-m-d H:i:s');
    $logMessage = "[{$timestamp}] [{$level}] {$message}" . PHP_EOL;
    
    // Escrever no arquivo de log
    file_put_contents(__DIR__ . '/debug_import.log', $logMessage, FILE_APPEND | LOCK_EX);
    
    // Também mostrar na tela
    echo $logMessage;
    flush();
    
    if (function_exists('fastcgi_finish_request')) {
        fastcgi_finish_request();
    }
}

function testServerLimits() {
    debugLog("=== TESTE DE CONFIGURAÇÕES DO SERVIDOR ===");
    debugLog("PHP Version: " . PHP_VERSION);
    debugLog("Max Execution Time: " . ini_get('max_execution_time'));
    debugLog("Memory Limit: " . ini_get('memory_limit'));
    debugLog("Upload Max Filesize: " . ini_get('upload_max_filesize'));
    debugLog("Post Max Size: " . ini_get('post_max_size'));
    debugLog("Max Input Time: " . ini_get('max_input_time'));
    debugLog("File Uploads: " . (ini_get('file_uploads') ? 'Enabled' : 'Disabled'));
    debugLog("Current Directory: " . getcwd());
    debugLog("Script Directory: " . __DIR__);
    debugLog("Document Root: " . $_SERVER['DOCUMENT_ROOT']);
}

function testFileAccess() {
    debugLog("=== TESTE DE ARQUIVOS ===");
    
    // Testar arquivos CSV possíveis
    $possibleFiles = [
        '../db.csv', 
        '../dados.csv', 
        '../uploads/dados.csv', 
        './db.csv', 
        './dados.csv',
        'db.csv',
        'dados.csv'
    ];
    
    foreach ($possibleFiles as $file) {
        if (file_exists($file)) {
            $size = filesize($file);
            $readable = is_readable($file);
            debugLog("✅ Arquivo encontrado: {$file} (Tamanho: {$size} bytes, Legível: " . ($readable ? 'SIM' : 'NÃO') . ")");
            
            // Tentar ler as primeiras linhas
            if ($readable) {
                $handle = fopen($file, 'r');
                if ($handle) {
                    $firstLine = fgets($handle);
                    $secondLine = fgets($handle);
                    fclose($handle);
                    debugLog("   Primeira linha: " . substr($firstLine, 0, 100) . "...");
                    debugLog("   Segunda linha: " . substr($secondLine, 0, 100) . "...");
                } else {
                    debugLog("   ❌ Erro ao abrir arquivo para leitura");
                }
            }
        } else {
            debugLog("❌ Arquivo não encontrado: {$file}");
        }
    }
}

function testDatabaseConfig() {
    debugLog("=== TESTE DE CONFIGURAÇÃO DO BANCO ===");
    
    $configFile = '../config/database.json';
    debugLog("Procurando config em: {$configFile}");
    
    if (!file_exists($configFile)) {
        debugLog("❌ Arquivo de configuração não encontrado: {$configFile}");
        
        // Tentar outros locais
        $otherLocations = [
            './config/database.json',
            'config/database.json',
            '../database.json',
            './database.json'
        ];
        
        foreach ($otherLocations as $location) {
            if (file_exists($location)) {
                debugLog("✅ Config encontrada em: {$location}");
                $configFile = $location;
                break;
            }
        }
        
        if (!file_exists($configFile)) {
            debugLog("❌ Nenhum arquivo de configuração encontrado");
            return false;
        }
    }
    
    $config = json_decode(file_get_contents($configFile), true);
    if (!$config) {
        debugLog("❌ Erro ao decodificar JSON da configuração");
        debugLog("Conteúdo do arquivo: " . file_get_contents($configFile));
        return false;
    }
    
    debugLog("✅ Configuração carregada:");
    debugLog("   Host: " . ($config['host'] ?? 'NÃO DEFINIDO'));
    debugLog("   Database: " . ($config['dbname'] ?? 'NÃO DEFINIDO'));
    debugLog("   Username: " . ($config['username'] ?? 'NÃO DEFINIDO'));
    debugLog("   Password: " . (isset($config['password']) ? '[DEFINIDA]' : 'NÃO DEFINIDA'));
    
    return $config;
}

function testDatabaseConnection($config) {
    debugLog("=== TESTE DE CONEXÃO COM BANCO ===");
    
    try {
        $dsn = "mysql:host={$config['host']};dbname={$config['dbname']};charset=utf8mb4";
        debugLog("DSN: {$dsn}");
        
        $pdo = new PDO(
            $dsn,
            $config['username'],
            $config['password'],
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_TIMEOUT => 10,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
            ]
        );
        
        debugLog("✅ Conexão estabelecida com sucesso!");
        
        // Testar tabela
        $stmt = $pdo->query("SHOW TABLES LIKE 'Associados'");
        if ($stmt->rowCount() > 0) {
            debugLog("✅ Tabela 'Associados' encontrada");
            
            $count = $pdo->query("SELECT COUNT(*) as total FROM Associados")->fetch();
            debugLog("   Registros existentes: " . $count['total']);
        } else {
            debugLog("❌ Tabela 'Associados' não encontrada");
        }
        
        return $pdo;
        
    } catch (PDOException $e) {
        debugLog("❌ Erro de conexão: " . $e->getMessage());
        debugLog("   Código do erro: " . $e->getCode());
        return false;
    }
}

function testPermissions() {
    debugLog("=== TESTE DE PERMISSÕES ===");
    
    // Testar escrita no diretório atual
    $testFile = './test_write.tmp';
    if (file_put_contents($testFile, 'test') !== false) {
        debugLog("✅ Permissão de escrita OK");
        unlink($testFile);
    } else {
        debugLog("❌ Sem permissão de escrita no diretório atual");
    }
    
    // Testar criação de diretório
    $testDir = './test_dir';
    if (mkdir($testDir, 0755, true)) {
        debugLog("✅ Permissão de criação de diretório OK");
        rmdir($testDir);
    } else {
        debugLog("❌ Sem permissão de criação de diretório");
    }
}

function testCSVProcessing() {
    debugLog("=== TESTE DE PROCESSAMENTO CSV ===");
    
    // Criar um CSV de teste
    $testCSV = './test.csv';
    $testData = "nome;cpf;email\nJoão Silva;12345678901;joao@email.com\nMaria Santos;98765432100;maria@email.com\n";
    
    if (file_put_contents($testCSV, $testData) === false) {
        debugLog("❌ Não foi possível criar arquivo de teste");
        return;
    }
    
    $handle = fopen($testCSV, 'r');
    if (!$handle) {
        debugLog("❌ Erro ao abrir arquivo CSV de teste");
        return;
    }
    
    $header = fgetcsv($handle, 0, ';');
    debugLog("✅ Cabeçalho lido: " . implode(', ', $header));
    
    $rowCount = 0;
    while (($row = fgetcsv($handle, 0, ';')) !== false) {
        $rowCount++;
        debugLog("   Linha {$rowCount}: " . implode(' | ', $row));
    }
    
    fclose($handle);
    unlink($testCSV);
    
    debugLog("✅ Processamento CSV funcional - {$rowCount} linhas processadas");
}

// EXECUTAR TODOS OS TESTES
try {
    debugLog("INICIANDO DIAGNÓSTICO COMPLETO");
    debugLog("Timestamp: " . date('Y-m-d H:i:s'));
    debugLog("===============================================");
    
    testServerLimits();
    debugLog("");
    
    testPermissions();
    debugLog("");
    
    testFileAccess();
    debugLog("");
    
    $config = testDatabaseConfig();
    debugLog("");
    
    if ($config) {
        $pdo = testDatabaseConnection($config);
        debugLog("");
    }
    
    testCSVProcessing();
    debugLog("");
    
    debugLog("===============================================");
    debugLog("DIAGNÓSTICO CONCLUÍDO!");
    debugLog("Verifique o arquivo 'debug_import.log' para detalhes");
    
} catch (Exception $e) {
    debugLog("ERRO CRÍTICO: " . $e->getMessage());
    debugLog("Stack trace: " . $e->getTraceAsString());
} catch (Error $e) {
    debugLog("ERRO FATAL: " . $e->getMessage());
    debugLog("Stack trace: " . $e->getTraceAsString());
}

debugLog("Fim do script de debug");
?>