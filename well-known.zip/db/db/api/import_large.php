<?php
// Importador CSV OTIMIZADO para Hostgator
error_reporting(E_ALL);
ini_set('display_errors', 1);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/import_errors.log');

// Configurações mais conservadoras para hosting compartilhado
ini_set('max_execution_time', 180); // 3 minutos
ini_set('memory_limit', '128M');
set_time_limit(180);

// Headers simples - sem streaming complexo
header('Content-Type: text/html; charset=utf-8');
header('Cache-Control: no-cache');

// Função de log simplificada
function logMessage($message, $level = 'info') {
    $timestamp = date('H:i:s');
    $logEntry = "[{$timestamp}] [{$level}] {$message}\n";
    
    // Log em arquivo
    file_put_contents(__DIR__ . '/import.log', $logEntry, FILE_APPEND | LOCK_EX);
    
    // Output direto (mais confiável que flush complexo)
    echo "<div class='log-{$level}'>[{$timestamp}] {$message}</div>\n";
    
    // Flush simples
    if (ob_get_level()) {
        ob_flush();
    }
    flush();
}

function checkRequirements() {
    logMessage("Verificando requisitos...");
    
    // Verificar extensões PHP
    $required = ['pdo', 'pdo_mysql', 'json'];
    foreach ($required as $ext) {
        if (!extension_loaded($ext)) {
            throw new Exception("Extensão PHP obrigatória não encontrada: {$ext}");
        }
    }
    
    logMessage("✅ Extensões PHP OK");
    
    // Verificar permissões
    if (!is_writable(__DIR__)) {
        throw new Exception("Diretório não tem permissão de escrita");
    }
    
    logMessage("✅ Permissões OK");
}

function findCSVFile() {
    $possibleFiles = [
        'db.csv',
        'dados.csv',
        '../db.csv', 
        '../dados.csv',
        './uploads/dados.csv'
    ];
    
    foreach ($possibleFiles as $file) {
        if (file_exists($file) && is_readable($file)) {
            logMessage("📁 Arquivo CSV encontrado: {$file}");
            return $file;
        }
    }
    
    throw new Exception("Arquivo CSV não encontrado. Arquivos procurados: " . implode(', ', $possibleFiles));
}

function loadDatabaseConfig() {
    $configLocations = [
        '../config/database.json',
        './config/database.json',
        'database.json',
        '../database.json'
    ];
    
    foreach ($configLocations as $configFile) {
        if (file_exists($configFile)) {
            $config = json_decode(file_get_contents($configFile), true);
            if ($config && isset($config['host'], $config['dbname'], $config['username'])) {
                logMessage("✅ Configuração do banco carregada de: {$configFile}");
                return $config;
            }
        }
    }
    
    throw new Exception("Arquivo de configuração do banco não encontrado ou inválido");
}

function connectDatabase($config) {
    try {
        $dsn = "mysql:host={$config['host']};dbname={$config['dbname']};charset=utf8mb4";
        
        $pdo = new PDO(
            $dsn,
            $config['username'],
            $config['password'] ?? '',
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_TIMEOUT => 30,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
            ]
        );
        
        // Configurações MySQL para compatibilidade
        $pdo->exec("SET SESSION sql_mode = ''");
        $pdo->exec("SET SESSION wait_timeout = 300");
        
        logMessage("✅ Conexão com banco estabelecida");
        return $pdo;
        
    } catch (PDOException $e) {
        throw new Exception("Erro de conexão com banco: " . $e->getMessage());
    }
}

function prepareStatements($pdo) {
    $statements = [];
    
    $statements['check'] = $pdo->prepare("SELECT id FROM Associados WHERE cpf = ? LIMIT 1");
    
    $statements['insert'] = $pdo->prepare("
        INSERT INTO Associados (nome, nasc, sexo, rg, cpf, email, situacao, escolaridade, estadoCivil, telefone) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    ");
    
    $statements['update'] = $pdo->prepare("
        UPDATE Associados SET 
            nome=?, nasc=?, sexo=?, rg=?, email=?, situacao=?, escolaridade=?, estadoCivil=?, telefone=? 
        WHERE id=?
    ");
    
    // Statements para tabelas relacionadas (com tratamento de erro)
    try {
        $statements['endereco'] = $pdo->prepare("
            INSERT INTO Endereco (associado_id, cep, endereco, bairro, cidade) 
            VALUES (?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE cep=VALUES(cep), endereco=VALUES(endereco), bairro=VALUES(bairro), cidade=VALUES(cidade)
        ");
    } catch (PDOException $e) {
        logMessage("⚠️ Tabela Endereco não disponível: " . $e->getMessage(), 'warning');
        $statements['endereco'] = null;
    }
    
    try {
        $statements['militar'] = $pdo->prepare("
            INSERT INTO Militar (associado_id, corporacao, patente, categoria, lotacao) 
            VALUES (?, ?, ?, ?, ?)
            ON DUPLICATE KEY UPDATE corporacao=VALUES(corporacao), patente=VALUES(patente), categoria=VALUES(categoria), lotacao=VALUES(lotacao)
        ");
    } catch (PDOException $e) {
        logMessage("⚠️ Tabela Militar não disponível: " . $e->getMessage(), 'warning');
        $statements['militar'] = null;
    }
    
    logMessage("✅ Statements preparados");
    return $statements;
}

function normalizeData($data) {
    // Sexo
    if (isset($data['sexo'])) {
        $sexo = strtolower(trim($data['sexo']));
        if (in_array($sexo, ['masculino', 'masc', 'm'])) {
            $data['sexo'] = 'M';
        } elseif (in_array($sexo, ['feminino', 'fem', 'f'])) {
            $data['sexo'] = 'F';
        } else {
            $data['sexo'] = null;
        }
    }
    
    // CPF
    if (isset($data['cpf'])) {
        $data['cpf'] = preg_replace('/[^0-9]/', '', $data['cpf']);
        if (strlen($data['cpf']) !== 11) {
            $data['cpf'] = '';
        }
    }
    
    // RG
    if (isset($data['rg'])) {
        $data['rg'] = preg_replace('/[^0-9]/', '', $data['rg']);
        if (empty($data['rg'])) {
            $data['rg'] = null;
        }
    }
    
    // Limpar valores inválidos
    foreach ($data as $campo => $valor) {
        if (in_array($valor, ['0000-00-00', 'NULL', 'null', '', '0', 'undefined'])) {
            $data[$campo] = null;
        } else if (is_string($valor)) {
            $data[$campo] = trim($valor);
        }
    }
    
    return $data;
}

function formatDate($date) {
    if (empty($date) || $date === '0000-00-00') return null;
    
    $date = trim($date);
    
    // Já está no formato correto
    if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) {
        return $date;
    }
    
    // Formato brasileiro dd/mm/yyyy
    if (preg_match('/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/', $date, $matches)) {
        return sprintf('%04d-%02d-%02d', $matches[3], $matches[2], $matches[1]);
    }
    
    return null;
}

// HTML básico para output
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Importação CSV - Hostgator</title>
    <style>
        body { font-family: monospace; background: #f5f5f5; margin: 20px; }
        .container { background: white; padding: 20px; border-radius: 5px; }
        .log-info { color: #333; }
        .log-success { color: #28a745; font-weight: bold; }
        .log-warning { color: #ffc107; }
        .log-error { color: #dc3545; font-weight: bold; }
        .stats { background: #e9ecef; padding: 10px; margin: 10px 0; border-radius: 3px; }
    </style>
</head>
<body>
<div class="container">
<h2>🚀 Importação CSV - Versão Hostgator</h2>

<?php
try {
    $startTime = microtime(true);
    
    // 1. Verificar requisitos
    checkRequirements();
    
    // 2. Encontrar arquivo CSV
    $csvFile = findCSVFile();
    
    // 3. Carregar configuração do banco
    $config = loadDatabaseConfig();
    
    // 4. Conectar ao banco
    $pdo = connectDatabase($config);
    
    // 5. Preparar statements
    $statements = prepareStatements($pdo);
    
    // 6. Analisar arquivo CSV
    logMessage("📊 Analisando arquivo CSV...");
    
    $handle = fopen($csvFile, 'r');
    if (!$handle) {
        throw new Exception("Erro ao abrir arquivo CSV");
    }
    
    // Detectar delimitador
    $firstLine = fgets($handle);
    $delimiter = (strpos($firstLine, ';') !== false) ? ';' : ',';
    rewind($handle);
    
    // Ler cabeçalho
    $header = fgetcsv($handle, 0, $delimiter);
    if (!$header) {
        throw new Exception("Erro ao ler cabeçalho do CSV");
    }
    
    $header = array_map('trim', $header);
    
    // Remover colunas vazias
    while (end($header) === '') {
        array_pop($header);
    }
    
    logMessage("📋 Colunas encontradas: " . count($header));
    logMessage("🔧 Delimitador: '{$delimiter}'");
    
    // Contar registros (método mais rápido)
    $totalRegistros = 0;
    while (fgetcsv($handle, 0, $delimiter) !== false) {
        $totalRegistros++;
    }
    
    logMessage("📊 Total de registros: {$totalRegistros}");
    
    // Voltar ao início
    rewind($handle);
    fgetcsv($handle, 0, $delimiter); // Pular cabeçalho
    
    // Mapeamento de campos
    $mapeamento = [
        'nome_ass' => 'nome',
        'data_nasc' => 'nasc', 
        'sexo' => 'sexo',
        'rg' => 'rg',
        'cpf' => 'cpf',
        'situação' => 'situacao',
        'escolaridade' => 'escolaridade',
        'est_civil' => 'estadoCivil',
        'email' => 'email',
        'fone_celular' => 'telefone',
        'cep' => 'cep',
        'endereco' => 'endereco',
        'bairro' => 'bairro',
        'cidade' => 'cidade',
        'corporação' => 'corporacao',
        'patente' => 'patente',
        'categoria' => 'categoria',
        'lotação' => 'lotacao'
    ];
    
    // Contadores
    $stats = [
        'processed' => 0,
        'inserted' => 0,
        'updated' => 0,
        'errors' => 0,
        'skipped' => 0
    ];
    
    logMessage("⚡ Iniciando processamento...");
    
    $batchSize = 25; // Lotes menores para hosting compartilhado
    $batchCount = 0;
    $lastUpdate = time();
    
    // Processar linha por linha
    while (($row = fgetcsv($handle, 0, $delimiter)) !== false) {
        try {
            $stats['processed']++;
            $batchCount++;
            
            // Verificar se ainda temos tempo
            if (time() - $startTime > 150) { // 2.5 minutos
                logMessage("⏰ Tempo limite próximo, parando processamento");
                break;
            }
            
            // Validar número de colunas
            if (count($row) !== count($header)) {
                $stats['errors']++;
                continue;
            }
            
            // Mapear dados
            $dadosOriginais = array_combine($header, $row);
            $dadosOriginais = array_map('trim', $dadosOriginais);
            
            $data = [];
            foreach ($mapeamento as $original => $novo) {
                $data[$novo] = $dadosOriginais[$original] ?? '';
            }
            
            // Normalizar
            $data = normalizeData($data);
            
            // Validar dados obrigatórios
            if (empty($data['cpf']) || strlen($data['cpf']) !== 11 || empty($data['nome'])) {
                $stats['skipped']++;
                continue;
            }
            
            // Verificar se associado existe
            $statements['check']->execute([$data['cpf']]);
            $associadoId = $statements['check']->fetchColumn();
            
            if ($associadoId) {
                // Atualizar existente
                $statements['update']->execute([
                    $data['nome'],
                    formatDate($data['nasc']),
                    $data['sexo'],
                    $data['rg'],
                    $data['email'],
                    $data['situacao'],
                    $data['escolaridade'],
                    $data['estadoCivil'],
                    $data['telefone'],
                    $associadoId
                ]);
                $stats['updated']++;
                
            } else {
                // Inserir novo
                $statements['insert']->execute([
                    $data['nome'],
                    formatDate($data['nasc']),
                    $data['sexo'],
                    $data['rg'],
                    $data['cpf'],
                    $data['email'],
                    $data['situacao'],
                    $data['escolaridade'],
                    $data['estadoCivil'],
                    $data['telefone']
                ]);
                
                $associadoId = $pdo->lastInsertId();
                $stats['inserted']++;
            }
            
            // Inserir dados relacionados (se disponível)
            if ($associadoId && $statements['endereco'] && 
                (!empty($data['cep']) || !empty($data['endereco']))) {
                try {
                    $statements['endereco']->execute([
                        $associadoId,
                        $data['cep'],
                        $data['endereco'],
                        $data['bairro'],
                        $data['cidade']
                    ]);
                } catch (PDOException $e) {
                    // Ignorar erros de endereço
                }
            }
            
            if ($associadoId && $statements['militar'] && 
                (!empty($data['corporacao']) || !empty($data['patente']))) {
                try {
                    $statements['militar']->execute([
                        $associadoId,
                        $data['corporacao'],
                        $data['patente'],
                        $data['categoria'],
                        $data['lotacao']
                    ]);
                } catch (PDOException $e) {
                    // Ignorar erros militares
                }
            }
            
            // Update status a cada lote
            if ($batchCount >= $batchSize || (time() - $lastUpdate) >= 5) {
                $percent = round(($stats['processed'] / $totalRegistros) * 100, 1);
                $remaining = $totalRegistros - $stats['processed'];
                
                echo "<div class='stats'>";
                echo "📊 Progresso: {$percent}% | ";
                echo "Processados: {$stats['processed']} | ";
                echo "Inseridos: {$stats['inserted']} | ";
                echo "Atualizados: {$stats['updated']} | ";
                echo "Erros: {$stats['errors']} | ";
                echo "Restam: {$remaining}";
                echo "</div>";
                
                $batchCount = 0;
                $lastUpdate = time();
                
                // Flush para mostrar progresso
                if (ob_get_level()) ob_flush();
                flush();
            }
            
        } catch (Exception $e) {
            $stats['errors']++;
            if ($stats['errors'] <= 5) { // Mostrar só os primeiros erros
                logMessage("❌ Erro linha {$stats['processed']}: " . $e->getMessage(), 'error');
            }
        }
    }
    
    fclose($handle);
    
    // Resultado final
    $elapsed = round(microtime(true) - $startTime, 2);
    
    echo "<div class='stats'>";
    logMessage("🎉 IMPORTAÇÃO CONCLUÍDA!", 'success');
    logMessage("⏱️ Tempo total: {$elapsed} segundos", 'success');
    logMessage("📊 RESUMO FINAL:", 'success');
    logMessage("   ✅ Inseridos: {$stats['inserted']}", 'success');
    logMessage("   🔄 Atualizados: {$stats['updated']}", 'success');
    logMessage("   ❌ Erros: {$stats['errors']}", $stats['errors'] > 0 ? 'warning' : 'success');
    logMessage("   ⏭️ Ignorados: {$stats['skipped']}", 'info');
    
    $totalProcessed = $stats['inserted'] + $stats['updated'];
    $successRate = $totalRegistros > 0 ? round(($totalProcessed / $totalRegistros) * 100, 1) : 0;
    logMessage("🏆 Taxa de sucesso: {$successRate}%", 'success');
    echo "</div>";
    
} catch (Exception $e) {
    logMessage("💥 ERRO CRÍTICO: " . $e->getMessage(), 'error');
    logMessage("Stack trace salvo no arquivo de log", 'error');
    
    // Salvar stack trace completo no log
    $errorDetails = "[ERROR] " . date('Y-m-d H:i:s') . " - " . $e->getMessage() . "\n";
    $errorDetails .= "Stack trace:\n" . $e->getTraceAsString() . "\n\n";
    file_put_contents(__DIR__ . '/import_errors.log', $errorDetails, FILE_APPEND | LOCK_EX);
}

logMessage("✅ Processo finalizado. Verifique os logs para detalhes.");
?>

</div>
</body>
</html>