<?php
// Diagnóstico: Por que os dados importados não aparecem na busca
error_reporting(E_ALL);
ini_set('display_errors', 1);

header('Content-Type: text/html; charset=utf-8');

function loadDatabaseConfig() {
    $configLocations = [
        '../config/database.json',
        './config/database.json',
        'database.json',
        '../database.json'
    ];
    
    foreach ($configLocations as $configFile) {
        if (file_exists($configFile)) {
            $config = json_decode(file_get_contents($configFile), true);
            if ($config && isset($config['host'], $config['dbname'], $config['username'])) {
                return $config;
            }
        }
    }
    
    throw new Exception("Arquivo de configuração do banco não encontrado");
}

function connectDatabase($config) {
    $dsn = "mysql:host={$config['host']};dbname={$config['dbname']};charset=utf8mb4";
    
    return new PDO(
        $dsn,
        $config['username'],
        $config['password'] ?? '',
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4"
        ]
    );
}

?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Diagnóstico - Dados Importados</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; background: #f5f5f5; }
        .container { background: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; }
        .success { color: #28a745; font-weight: bold; }
        .warning { color: #ffc107; font-weight: bold; }
        .error { color: #dc3545; font-weight: bold; }
        .info { color: #17a2b8; }
        table { width: 100%; border-collapse: collapse; margin: 10px 0; }
        th, td { border: 1px solid #ddd; padding: 8px; text-align: left; }
        th { background-color: #f2f2f2; }
        .query-box { background: #f8f9fa; padding: 15px; border-radius: 5px; margin: 10px 0; }
        .code { background: #e9ecef; padding: 10px; border-radius: 3px; font-family: monospace; }
    </style>
</head>
<body>

<div class="container">
    <h2>🔍 Diagnóstico - Por que os dados não aparecem na busca?</h2>
    
    <?php
    try {
        $config = loadDatabaseConfig();
        $pdo = connectDatabase($config);
        
        echo "<p class='success'>✅ Conectado ao banco: {$config['dbname']}</p>";
        
        // 1. VERIFICAR TOTAL DE REGISTROS
        echo "<h3>📊 1. Contagem Total de Registros</h3>";
        $stmt = $pdo->query("SELECT COUNT(*) as total FROM Associados");
        $total = $stmt->fetch()['total'];
        echo "<p class='info'><strong>Total de associados no banco: {$total}</strong></p>";
        
        if ($total == 0) {
            echo "<p class='error'>❌ PROBLEMA: Não há registros na tabela! A importação pode não ter funcionado.</p>";
        } else {
            echo "<p class='success'>✅ Dados estão no banco!</p>";
        }
        
        // 2. VERIFICAR REGISTROS RECENTES
        echo "<h3>📅 2. Registros Criados/Atualizados Recentemente</h3>";
        
        // Verificar se existe campo de timestamp
        $columns = $pdo->query("DESCRIBE Associados")->fetchAll();
        $hasTimestamp = false;
        $timestampField = '';
        
        foreach ($columns as $col) {
            if (in_array($col['Field'], ['created_at', 'updated_at', 'data_criacao', 'data_atualizacao'])) {
                $hasTimestamp = true;
                $timestampField = $col['Field'];
                break;
            }
        }
        
        if ($hasTimestamp) {
            $stmt = $pdo->query("SELECT COUNT(*) as recentes FROM Associados WHERE {$timestampField} >= DATE_SUB(NOW(), INTERVAL 1 HOUR)");
            $recentes = $stmt->fetch()['recentes'];
            echo "<p class='info'>Registros criados/atualizados na última hora: <strong>{$recentes}</strong></p>";
        } else {
            echo "<p class='warning'>⚠️ Tabela não tem campo de timestamp para verificar registros recentes</p>";
        }
        
        // 3. VERIFICAR ÚLTIMOS REGISTROS INSERIDOS
        echo "<h3>👥 3. Últimos 10 Registros Inseridos</h3>";
        $stmt = $pdo->query("SELECT id, nome, cpf, email FROM Associados ORDER BY id DESC LIMIT 10");
        $ultimos = $stmt->fetchAll();
        
        if ($ultimos) {
            echo "<table>";
            echo "<tr><th>ID</th><th>Nome</th><th>CPF</th><th>Email</th></tr>";
            foreach ($ultimos as $assoc) {
                echo "<tr>";
                echo "<td>{$assoc['id']}</td>";
                echo "<td>" . htmlspecialchars($assoc['nome']) . "</td>";
                echo "<td>{$assoc['cpf']}</td>";
                echo "<td>" . htmlspecialchars($assoc['email']) . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        } else {
            echo "<p class='error'>❌ Nenhum registro encontrado!</p>";
        }
        
        // 4. TESTE DE BUSCA POR NOME
        echo "<h3>🔍 4. Teste de Busca por Nome</h3>";
        
        if ($ultimos) {
            $primeiroNome = $ultimos[0]['nome'];
            $palavraBusca = explode(' ', $primeiroNome)[0]; // Primeira palavra
            
            echo "<p>Testando busca pela palavra: <strong>'{$palavraBusca}'</strong></p>";
            
            // Busca exata
            $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM Associados WHERE nome = ?");
            $stmt->execute([$primeiroNome]);
            $buscaExata = $stmt->fetch()['total'];
            echo "<p>Busca exata por '{$primeiroNome}': <strong>{$buscaExata}</strong> resultado(s)</p>";
            
            // Busca com LIKE
            $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM Associados WHERE nome LIKE ?");
            $stmt->execute(["%{$palavraBusca}%"]);
            $buscaLike = $stmt->fetch()['total'];
            echo "<p>Busca com LIKE '%{$palavraBusca}%': <strong>{$buscaLike}</strong> resultado(s)</p>";
            
            // Busca case-insensitive
            $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM Associados WHERE LOWER(nome) LIKE LOWER(?)");
            $stmt->execute(["%{$palavraBusca}%"]);
            $buscaInsensitive = $stmt->fetch()['total'];
            echo "<p>Busca case-insensitive: <strong>{$buscaInsensitive}</strong> resultado(s)</p>";
        }
        
        // 5. VERIFICAR ENCODING/CHARSET
        echo "<h3>🔤 5. Verificação de Encoding</h3>";
        
        $stmt = $pdo->query("SELECT nome FROM Associados WHERE nome LIKE '%ã%' OR nome LIKE '%ç%' OR nome LIKE '%é%' LIMIT 5");
        $nomes_acentos = $stmt->fetchAll();
        
        if ($nomes_acentos) {
            echo "<p class='success'>✅ Encontrados nomes com acentos:</p>";
            foreach ($nomes_acentos as $nome) {
                echo "<p>• " . htmlspecialchars($nome['nome']) . "</p>";
            }
        } else {
            echo "<p class='warning'>⚠️ Nenhum nome com acentos encontrado (pode ser problema de encoding)</p>";
        }
        
        // 6. ESTRUTURA DA TABELA
        echo "<h3>🏗️ 6. Estrutura da Tabela</h3>";
        echo "<table>";
        echo "<tr><th>Campo</th><th>Tipo</th><th>Null</th><th>Chave</th><th>Default</th></tr>";
        foreach ($columns as $col) {
            echo "<tr>";
            echo "<td>{$col['Field']}</td>";
            echo "<td>{$col['Type']}</td>";
            echo "<td>{$col['Null']}</td>";
            echo "<td>{$col['Key']}</td>";
            echo "<td>{$col['Default']}</td>";
            echo "</tr>";
        }
        echo "</table>";
        
        // 7. VERIFICAR ÍNDICES
        echo "<h3>📇 7. Índices da Tabela</h3>";
        $indices = $pdo->query("SHOW INDEX FROM Associados")->fetchAll();
        
        if ($indices) {
            echo "<table>";
            echo "<tr><th>Nome do Índice</th><th>Coluna</th><th>Único</th></tr>";
            foreach ($indices as $idx) {
                echo "<tr>";
                echo "<td>{$idx['Key_name']}</td>";
                echo "<td>{$idx['Column_name']}</td>";
                echo "<td>" . ($idx['Non_unique'] ? 'Não' : 'Sim') . "</td>";
                echo "</tr>";
            }
            echo "</table>";
        }
        
        // 8. QUERIES DE TESTE PARA USAR NA SUA APLICAÇÃO
        echo "<h3>🧪 8. Queries de Teste para Sua Aplicação</h3>";
        
        echo "<div class='query-box'>";
        echo "<h4>Query para busca geral (recomendada):</h4>";
        echo "<div class='code'>";
        echo "SELECT id, nome, cpf, email, telefone<br>";
        echo "FROM Associados<br>";
        echo "WHERE LOWER(nome) LIKE LOWER(CONCAT('%', ?, '%'))<br>";
        echo "   OR cpf LIKE CONCAT('%', ?, '%')<br>";
        echo "   OR email LIKE LOWER(CONCAT('%', ?, '%'))<br>";
        echo "ORDER BY nome<br>";
        echo "LIMIT 50";
        echo "</div>";
        echo "</div>";
        
        echo "<div class='query-box'>";
        echo "<h4>Query para contar total (para paginação):</h4>";
        echo "<div class='code'>";
        echo "SELECT COUNT(*) as total<br>";
        echo "FROM Associados<br>";
        echo "WHERE LOWER(nome) LIKE LOWER(CONCAT('%', ?, '%'))<br>";
        echo "   OR cpf LIKE CONCAT('%', ?, '%')<br>";
        echo "   OR email LIKE LOWER(CONCAT('%', ?, '%'))";
        echo "</div>";
        echo "</div>";
        
        echo "<div class='query-box'>";
        echo "<h4>Verificar se o problema é cache:</h4>";
        echo "<div class='code'>";
        echo "SELECT SQL_NO_CACHE id, nome, cpf<br>";
        echo "FROM Associados<br>";
        echo "ORDER BY id DESC<br>";
        echo "LIMIT 10";
        echo "</div>";
        echo "</div>";
        
        // 9. POSSÍVEIS PROBLEMAS
        echo "<h3>⚠️ 9. Possíveis Problemas e Soluções</h3>";
        
        echo "<div class='query-box'>";
        echo "<h4>Problema 1: Cache da Aplicação</h4>";
        echo "<p><strong>Solução:</strong> Limpe o cache da aplicação, reinicie o servidor web, ou force refresh (Ctrl+F5)</p>";
        echo "</div>";
        
        echo "<div class='query-box'>";
        echo "<h4>Problema 2: Query de Busca Incorreta</h4>";
        echo "<p><strong>Solução:</strong> Use as queries de teste acima. Certifique-se de usar LIKE com % e LOWER() para case-insensitive</p>";
        echo "</div>";
        
        echo "<div class='query-box'>";
        echo "<h4>Problema 3: Tabela/Campo Errado</h4>";
        echo "<p><strong>Solução:</strong> Verifique se sua aplicação está consultando a tabela 'Associados' e os campos corretos</p>";
        echo "</div>";
        
        echo "<div class='query-box'>";
        echo "<h4>Problema 4: Encoding/Charset</h4>";
        echo "<p><strong>Solução:</strong> Certifique-se de usar UTF-8 em toda aplicação e nas conexões do banco</p>";
        echo "</div>";
        
        // 10. TESTE FINAL
        echo "<h3>🎯 10. Teste Final - Busca Simples</h3>";
        
        echo "<form method='GET' style='margin: 20px 0;'>";
        echo "<input type='text' name='busca' placeholder='Digite um nome para testar...' value='" . htmlspecialchars($_GET['busca'] ?? '') . "' style='padding: 8px; width: 300px;'>";
        echo "<input type='submit' value='Buscar' style='padding: 8px 15px; margin-left: 10px;'>";
        echo "</form>";
        
        if (isset($_GET['busca']) && !empty($_GET['busca'])) {
            $termoBusca = $_GET['busca'];
            echo "<h4>Resultados para: '{$termoBusca}'</h4>";
            
            $stmt = $pdo->prepare("
                SELECT id, nome, cpf, email 
                FROM Associados 
                WHERE LOWER(nome) LIKE LOWER(?) 
                   OR cpf LIKE ? 
                   OR LOWER(email) LIKE LOWER(?) 
                ORDER BY nome 
                LIMIT 20
            ");
            
            $buscaTermo = "%{$termoBusca}%";
            $stmt->execute([$buscaTermo, $buscaTermo, $buscaTermo]);
            $resultados = $stmt->fetchAll();
            
            if ($resultados) {
                echo "<p class='success'>✅ Encontrados " . count($resultados) . " resultado(s):</p>";
                echo "<table>";
                echo "<tr><th>ID</th><th>Nome</th><th>CPF</th><th>Email</th></tr>";
                foreach ($resultados as $res) {
                    echo "<tr>";
                    echo "<td>{$res['id']}</td>";
                    echo "<td>" . htmlspecialchars($res['nome']) . "</td>";
                    echo "<td>{$res['cpf']}</td>";
                    echo "<td>" . htmlspecialchars($res['email']) . "</td>";
                    echo "</tr>";
                }
                echo "</table>";
            } else {
                echo "<p class='error'>❌ Nenhum resultado encontrado para '{$termoBusca}'</p>";
                
                // Tentar busca mais ampla
                $stmt = $pdo->prepare("SELECT COUNT(*) as total FROM Associados WHERE nome LIKE ?");
                $stmt->execute(["%{$termoBusca}%"]);
                $totalParcial = $stmt->fetch()['total'];
                
                if ($totalParcial > 0) {
                    echo "<p class='warning'>⚠️ Mas encontrei {$totalParcial} registro(s) com busca case-sensitive</p>";
                }
            }
        }
        
    } catch (Exception $e) {
        echo "<p class='error'>❌ Erro: " . $e->getMessage() . "</p>";
    }
    ?>
</div>

</body>
</html>