<?php
/**
 * Arquivo de verificação de sessão
 * Inclua este arquivo no topo de todas as páginas que precisam de autenticação
 */

// Inicia a sessão se ainda não foi iniciada
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Verifica se o usuário está logado
if (!isset($_SESSION['funcionario_id'])) {
    $_SESSION['erro_login'] = 'Você precisa fazer login para acessar esta página.';
    header('Location: ' . dirname($_SERVER['PHP_SELF']) . '/login.php');
    exit;
}

// Verifica timeout de sessão (30 minutos de inatividade)
$tempoInatividade = 1800; // 30 minutos em segundos

if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > $tempoInatividade)) {
    // Sessão expirou por inatividade
    session_unset();
    session_destroy();
    session_start();
    $_SESSION['erro_login'] = 'Sua sessão expirou por inatividade. Por favor, faça login novamente.';
    header('Location: ' . dirname($_SERVER['PHP_SELF']) . '/login.php');
    exit;
}

// Atualiza o tempo da última atividade
$_SESSION['last_activity'] = time();

// Verifica se a sessão é válida (proteção contra session hijacking)
$ip = $_SERVER['REMOTE_ADDR'] ?? '';
$userAgent = $_SERVER['HTTP_USER_AGENT'] ?? '';

// Cria um fingerprint da sessão
$sessionFingerprint = md5($ip . $userAgent);

if (!isset($_SESSION['fingerprint'])) {
    $_SESSION['fingerprint'] = $sessionFingerprint;
} elseif ($_SESSION['fingerprint'] !== $sessionFingerprint) {
    // Possível tentativa de session hijacking
    session_unset();
    session_destroy();
    session_start();
    $_SESSION['erro_login'] = 'Sessão inválida detectada. Por favor, faça login novamente.';
    header('Location: ' . dirname($_SERVER['PHP_SELF']) . '/login.php');
    exit;
}

// Função auxiliar para verificar permissão específica
function verificarPermissao($recurso, $acao = 'visualizar') {
    if (!isset($_SESSION['permissoes'][$recurso])) {
        return false;
    }
    
    return in_array($acao, $_SESSION['permissoes'][$recurso]);
}

// Função para obter dados do usuário logado
function getUsuarioLogado() {
    return [
        'id' => $_SESSION['funcionario_id'] ?? null,
        'nome' => $_SESSION['funcionario_nome'] ?? '',
        'email' => $_SESSION['funcionario_email'] ?? '',
        'cargo' => $_SESSION['funcionario_cargo'] ?? '',
        'foto' => $_SESSION['funcionario_foto'] ?? '',
        'departamento_id' => $_SESSION['departamento_id'] ?? null,
        'departamento_nome' => $_SESSION['departamento_nome'] ?? ''
    ];
}

// Define constantes úteis
define('USUARIO_LOGADO_ID', $_SESSION['funcionario_id'] ?? 0);
define('USUARIO_LOGADO_NOME', $_SESSION['funcionario_nome'] ?? '');
define('USUARIO_LOGADO_EMAIL', $_SESSION['funcionario_email'] ?? '');
?>