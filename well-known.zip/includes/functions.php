<?php
/**
 * Arquivo de funções auxiliares do sistema ASSEGO
 */

// Inclui a configuração do banco se ainda não foi incluída
require_once __DIR__ . '/../config/database.php';

/**
 * Função para validar CPF
 */
function validarCPF($cpf) {
    // Remove caracteres não numéricos
    $cpf = preg_replace('/[^0-9]/', '', $cpf);
    
    // Verifica se tem 11 dígitos
    if (strlen($cpf) != 11) {
        return false;
    }
    
    // Verifica sequências inválidas
    if (preg_match('/(\d)\1{10}/', $cpf)) {
        return false;
    }
    
    // Valida primeiro dígito verificador
    for ($t = 9; $t < 11; $t++) {
        for ($d = 0, $c = 0; $c < $t; $c++) {
            $d += $cpf[$c] * (($t + 1) - $c);
        }
        $d = ((10 * $d) % 11) % 10;
        if ($cpf[$c] != $d) {
            return false;
        }
    }
    
    return true;
}

/**
 * Função para formatar CPF
 */
function formatarCPF($cpf) {
    $cpf = preg_replace('/[^0-9]/', '', $cpf);
    return preg_replace('/(\d{3})(\d{3})(\d{3})(\d{2})/', '$1.$2.$3-$4', $cpf);
}

/**
 * Função para formatar telefone
 */
function formatarTelefone($telefone) {
    $telefone = preg_replace('/[^0-9]/', '', $telefone);
    
    if (strlen($telefone) == 11) {
        return preg_replace('/(\d{2})(\d{5})(\d{4})/', '($1) $2-$3', $telefone);
    } elseif (strlen($telefone) == 10) {
        return preg_replace('/(\d{2})(\d{4})(\d{4})/', '($1) $2-$3', $telefone);
    }
    
    return $telefone;
}

/**
 * Função para formatar data
 */
function formatarData($data, $formato = 'd/m/Y') {
    if (empty($data)) return '';
    return date($formato, strtotime($data));
}

/**
 * Função para gerar hash de senha seguro
 */
function gerarHashSenha($senha) {
    return password_hash($senha, PASSWORD_BCRYPT, ['cost' => 12]);
}

/**
 * Função para verificar senha
 */
function verificarSenha($senha, $hash) {
    return password_verify($senha, $hash);
}

/**
 * Função para gerar token aleatório
 */
function gerarToken($tamanho = 32) {
    return bin2hex(random_bytes($tamanho));
}

/**
 * Função para sanitizar entrada
 */
function sanitizar($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    return $data;
}

/**
 * Função para validar email
 */
function validarEmail($email) {
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

/**
 * Função para upload seguro de arquivos
 */
function uploadArquivo($arquivo, $diretorio, $tiposPermitidos = ['pdf', 'jpg', 'jpeg', 'png']) {
    $resultado = ['sucesso' => false, 'mensagem' => '', 'arquivo' => ''];
    
    // Verifica se houve erro no upload
    if ($arquivo['error'] !== UPLOAD_ERR_OK) {
        $resultado['mensagem'] = 'Erro no upload do arquivo.';
        return $resultado;
    }
    
    // Verifica o tamanho do arquivo (máximo 10MB)
    if ($arquivo['size'] > 10485760) {
        $resultado['mensagem'] = 'Arquivo muito grande. Tamanho máximo: 10MB.';
        return $resultado;
    }
    
    // Obtém a extensão do arquivo
    $extensao = strtolower(pathinfo($arquivo['name'], PATHINFO_EXTENSION));
    
    // Verifica se a extensão é permitida
    if (!in_array($extensao, $tiposPermitidos)) {
        $resultado['mensagem'] = 'Tipo de arquivo não permitido.';
        return $resultado;
    }
    
    // Gera um nome único para o arquivo
    $nomeArquivo = uniqid() . '_' . time() . '.' . $extensao;
    $caminhoCompleto = $diretorio . '/' . $nomeArquivo;
    
    // Move o arquivo para o diretório de destino
    if (move_uploaded_file($arquivo['tmp_name'], $caminhoCompleto)) {
        $resultado['sucesso'] = true;
        $resultado['mensagem'] = 'Arquivo enviado com sucesso.';
        $resultado['arquivo'] = $nomeArquivo;
    } else {
        $resultado['mensagem'] = 'Erro ao mover o arquivo.';
    }
    
    return $resultado;
}

/**
 * Função para registrar log de atividade
 */
function registrarLog($acao, $detalhes = '', $usuarioId = null) {
    $db = db();
    
    $ip = $_SERVER['REMOTE_ADDR'] ?? 'Unknown';
    $userAgent = $_SERVER['HTTP_USER_AGENT'] ?? 'Unknown';
    $sessaoId = session_id();
    
    $sql = "INSERT INTO Auditoria (tabela, acao, funcionario_id, associado_id, alteracoes, ip_origem, browser_info, sessao_id) 
            VALUES (:tabela, :acao, :funcionario_id, :associado_id, :alteracoes, :ip, :browser, :sessao)";
    
    $params = [
        'tabela' => 'Sistema',
        'acao' => $acao,
        'funcionario_id' => $_SESSION['funcionario_id'] ?? null,
        'associado_id' => $usuarioId,
        'alteracoes' => $detalhes,
        'ip' => $ip,
        'browser' => $userAgent,
        'sessao' => $sessaoId
    ];
    
    try {
        $db->query($sql, $params);
        return true;
    } catch (Exception $e) {
        error_log("Erro ao registrar log: " . $e->getMessage());
        return false;
    }
}

/**
 * Função para verificar permissão
 */
function temPermissao($recurso, $acao = 'visualizar') {
    if (!isset($_SESSION['funcionario_id'])) {
        return false;
    }
    
    $db = db();
    
    $sql = "SELECT tem_permissao 
            FROM vw_permissoes_efetivas 
            WHERE funcionario_id = :funcionario_id 
            AND recurso_chave = :recurso 
            AND permissao_nome = :acao 
            AND tem_permissao = 1";
    
    $params = [
        'funcionario_id' => $_SESSION['funcionario_id'],
        'recurso' => $recurso,
        'acao' => $acao
    ];
    
    $resultado = $db->fetchOne($sql, $params);
    
    return !empty($resultado);
}

/**
 * Função para gerar mensagem de alerta
 */
function gerarAlerta($tipo, $mensagem) {
    $icones = [
        'success' => 'check-circle',
        'danger' => 'exclamation-triangle',
        'warning' => 'exclamation-circle',
        'info' => 'info-circle'
    ];
    
    $icone = $icones[$tipo] ?? 'info-circle';
    
    return '<div class="alert alert-' . $tipo . ' alert-dismissible fade show" role="alert">
                <i class="fas fa-' . $icone . ' me-2"></i>
                ' . $mensagem . '
                <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
            </div>';
}

/**
 * Função para paginar resultados
 */
function paginar($totalRegistros, $registrosPorPagina = 10, $paginaAtual = 1) {
    $totalPaginas = ceil($totalRegistros / $registrosPorPagina);
    $offset = ($paginaAtual - 1) * $registrosPorPagina;
    
    return [
        'total_registros' => $totalRegistros,
        'registros_por_pagina' => $registrosPorPagina,
        'pagina_atual' => $paginaAtual,
        'total_paginas' => $totalPaginas,
        'offset' => $offset,
        'limit' => $registrosPorPagina
    ];
}

/**
 * Função para exportar dados para CSV
 */
function exportarCSV($dados, $nomeArquivo = 'export.csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=' . $nomeArquivo);
    
    $output = fopen('php://output', 'w');
    
    // Adiciona BOM para UTF-8
    fprintf($output, chr(0xEF).chr(0xBB).chr(0xBF));
    
    // Cabeçalhos
    if (!empty($dados)) {
        fputcsv($output, array_keys($dados[0]), ';');
    }
    
    // Dados
    foreach ($dados as $linha) {
        fputcsv($output, $linha, ';');
    }
    
    fclose($output);
    exit;
}

/**
 * Função para obter patentes disponíveis
 */
function getPatentes() {
    return [
        'Soldado',
        'Cabo',
        '3º Sargento',
        '2º Sargento',
        '1º Sargento',
        'Subtenente',
        'Aspirante',
        '2º Tenente',
        '1º Tenente',
        'Capitão',
        'Major',
        'Tenente-Coronel',
        'Coronel'
    ];
}

/**
 * Função para obter corporações
 */
function getCorporacoes() {
    return [
        'PM' => 'Polícia Militar',
        'BM' => 'Corpo de Bombeiros',
        'PC' => 'Polícia Civil',
        'PP' => 'Polícia Penal',
        'PF' => 'Polícia Federal',
        'PRF' => 'Polícia Rodoviária Federal'
    ];
}

/**
 * Função para calcular idade
 */
function calcularIdade($dataNascimento) {
    if (empty($dataNascimento)) return 0;
    
    $nascimento = new DateTime($dataNascimento);
    $hoje = new DateTime();
    $idade = $hoje->diff($nascimento);
    
    return $idade->y;
}

/**
 * Função para formatar valor monetário
 */
function formatarMoeda($valor) {
    return 'R$ ' . number_format($valor, 2, ',', '.');
}

/**
 * Função para limpar string para URL
 */
function slugify($text) {
    // Substitui acentos
    $text = iconv('UTF-8', 'ASCII//TRANSLIT', $text);
    
    // Substitui espaços por hífens
    $text = preg_replace('/[^a-zA-Z0-9-]/', '-', $text);
    
    // Remove hífens duplicados
    $text = preg_replace('/-+/', '-', $text);
    
    // Remove hífens do início e fim
    $text = trim($text, '-');
    
    // Converte para minúsculas
    return strtolower($text);
}

/**
 * Função para gerar código único
 */
function gerarCodigoUnico($prefixo = '', $tamanho = 8) {
    $codigo = $prefixo . strtoupper(substr(md5(uniqid(rand(), true)), 0, $tamanho));
    return $codigo;
}

/**
 * Função para verificar se é uma requisição AJAX
 */
function isAjax() {
    return !empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
           strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest';
}

/**
 * Função para enviar resposta JSON
 */
function jsonResponse($data, $statusCode = 200) {
    http_response_code($statusCode);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

/**
 * Função para obter IP real do cliente
 */
function getClientIP() {
    $ipKeys = ['HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'];
    
    foreach ($ipKeys as $key) {
        if (!empty($_SERVER[$key])) {
            $ip = $_SERVER[$key];
            
            // Se houver múltiplos IPs, pega o primeiro
            if (strpos($ip, ',') !== false) {
                $ip = explode(',', $ip)[0];
            }
            
            // Valida o IP
            if (filter_var(trim($ip), FILTER_VALIDATE_IP)) {
                return trim($ip);
            }
        }
    }
    
    return 'Unknown';
}

/**
 * Função para criar thumbnail de imagem
 */
function criarThumbnail($origem, $destino, $largura = 150, $altura = 150) {
    $info = getimagesize($origem);
    
    if ($info === false) {
        return false;
    }
    
    // Obtém tipo e cria imagem baseada no tipo
    switch ($info['mime']) {
        case 'image/jpeg':
            $imagem = imagecreatefromjpeg($origem);
            break;
        case 'image/png':
            $imagem = imagecreatefrompng($origem);
            break;
        case 'image/gif':
            $imagem = imagecreatefromgif($origem);
            break;
        default:
            return false;
    }
    
    // Calcula proporções
    $larguraOriginal = $info[0];
    $alturaOriginal = $info[1];
    $ratio = min($largura / $larguraOriginal, $altura / $alturaOriginal);
    
    $novaLargura = $larguraOriginal * $ratio;
    $novaAltura = $alturaOriginal * $ratio;
    
    // Cria nova imagem
    $thumb = imagecreatetruecolor($novaLargura, $novaAltura);
    
    // Preserva transparência para PNG e GIF
    if ($info['mime'] == 'image/png' || $info['mime'] == 'image/gif') {
        imagecolortransparent($thumb, imagecolorallocatealpha($thumb, 0, 0, 0, 127));
        imagealphablending($thumb, false);
        imagesavealpha($thumb, true);
    }
    
    // Redimensiona
    imagecopyresampled($thumb, $imagem, 0, 0, 0, 0, 
                       $novaLargura, $novaAltura, $larguraOriginal, $alturaOriginal);
    
    // Salva imagem
    switch ($info['mime']) {
        case 'image/jpeg':
            imagejpeg($thumb, $destino, 85);
            break;
        case 'image/png':
            imagepng($thumb, $destino, 8);
            break;
        case 'image/gif':
            imagegif($thumb, $destino);
            break;
    }
    
    // Libera memória
    imagedestroy($imagem);
    imagedestroy($thumb);
    
    return true;
}

/**
 * Função para debug (apenas em desenvolvimento)
 */
function debug($data, $die = false) {
    echo '<pre style="background: #f4f4f4; padding: 10px; border: 1px solid #ddd; margin: 10px;">';
    print_r($data);
    echo '</pre>';
    
    if ($die) {
        die();
    }
}
?>