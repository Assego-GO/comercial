<?php
// Carrega as variáveis de ambiente
function loadEnv($path = '.env') {
    if (!file_exists($path)) {
        throw new Exception("Arquivo .env não encontrado!");
    }
    
    $lines = file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES);
    foreach ($lines as $line) {
        if (strpos(trim($line), '#') === 0) continue;
        
        list($name, $value) = explode('=', $line, 2);
        $name = trim($name);
        $value = trim($value);
        
        // Remove aspas se existirem
        if (preg_match('/^"(.*)"$/', $value, $matches)) {
            $value = $matches[1];
        }
        
        putenv(sprintf('%s=%s', $name, $value));
        $_ENV[$name] = $value;
        $_SERVER[$name] = $value;
    }
}

// Classe para gerenciar a conexão com o banco
class Database {
    private static $instance = null;
    private $connection;
    
    private function __construct() {
        try {
            // Carrega as configurações do .env
            loadEnv(__DIR__ . '/../.env');
            
            $host = getenv('DB_HOST');
            $port = getenv('DB_PORT');
            $dbname = getenv('DB_DATABASE');
            $username = getenv('DB_USERNAME');
            $password = getenv('DB_PASSWORD');
            
            $dsn = "mysql:host=$host;port=$port;dbname=$dbname;charset=utf8mb4";
            
            $options = [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false,
                PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
            ];
            
            $this->connection = new PDO($dsn, $username, $password, $options);
            
        } catch (PDOException $e) {
            die("Erro na conexão com o banco de dados: " . $e->getMessage());
        }
    }
    
    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    public function getConnection() {
        return $this->connection;
    }
    
    // Método para executar queries
    public function query($sql, $params = []) {
        try {
            $stmt = $this->connection->prepare($sql);
            $stmt->execute($params);
            return $stmt;
        } catch (PDOException $e) {
            throw new Exception("Erro na query: " . $e->getMessage());
        }
    }
    
    // Método para inserir dados
    public function insert($table, $data) {
        $fields = array_keys($data);
        $values = array_map(function($field) { return ":$field"; }, $fields);
        
        $sql = "INSERT INTO $table (" . implode(', ', $fields) . ") VALUES (" . implode(', ', $values) . ")";
        
        $this->query($sql, $data);
        return $this->connection->lastInsertId();
    }
    
    // Método para atualizar dados
    public function update($table, $data, $where, $whereParams = []) {
        $sets = array_map(function($field) { return "$field = :$field"; }, array_keys($data));
        
        $sql = "UPDATE $table SET " . implode(', ', $sets) . " WHERE $where";
        
        $this->query($sql, array_merge($data, $whereParams));
        return $this->connection->rowCount();
    }
    
    // Método para deletar dados
    public function delete($table, $where, $params = []) {
        $sql = "DELETE FROM $table WHERE $where";
        $this->query($sql, $params);
        return $this->connection->rowCount();
    }
    
    // Método para buscar um registro
    public function fetchOne($sql, $params = []) {
        $stmt = $this->query($sql, $params);
        return $stmt->fetch();
    }
    
    // Método para buscar múltiplos registros
    public function fetchAll($sql, $params = []) {
        $stmt = $this->query($sql, $params);
        return $stmt->fetchAll();
    }
    
    // Previne clonagem da instância
    private function __clone() {}
    
    // Previne desserialização da instância
    public function __wakeup() {
        throw new Exception("Cannot unserialize singleton");
    }
}

// Função helper para obter a instância do banco
function db() {
    return Database::getInstance();
}