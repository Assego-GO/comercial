<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Debug AJAX - ASSEGO</title>
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <style>
        body {
            font-family: Arial, sans-serif;
            padding: 20px;
            background: #f5f5f5;
        }
        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .test-section {
            margin-bottom: 30px;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        .test-section h3 {
            margin-top: 0;
            color: #333;
        }
        .status {
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
        }
        .success {
            background: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
        }
        .error {
            background: #f8d7da;
            color: #721c24;
            border: 1px solid #f5c6cb;
        }
        .warning {
            background: #fff3cd;
            color: #856404;
            border: 1px solid #ffeeba;
        }
        .info {
            background: #d1ecf1;
            color: #0c5460;
            border: 1px solid #bee5eb;
        }
        pre {
            background: #f4f4f4;
            padding: 10px;
            border-radius: 5px;
            overflow-x: auto;
            white-space: pre-wrap;
        }
        button {
            background: #007bff;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            margin-right: 10px;
        }
        button:hover {
            background: #0056b3;
        }
        .loading {
            display: inline-block;
            margin-left: 10px;
        }
        .log {
            background: #f8f9fa;
            border: 1px solid #dee2e6;
            padding: 10px;
            margin-top: 10px;
            max-height: 300px;
            overflow-y: auto;
            font-family: monospace;
            font-size: 12px;
        }
        .log-entry {
            margin: 2px 0;
            padding: 2px 5px;
        }
        .log-error {
            color: #dc3545;
        }
        .log-success {
            color: #28a745;
        }
        .log-info {
            color: #17a2b8;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Debug do Sistema ASSEGO</h1>
        <p>Esta página ajudará a identificar o problema de carregamento infinito.</p>

        <!-- Teste 1: Verificar jQuery -->
        <div class="test-section">
            <h3>1. Teste jQuery</h3>
            <button onclick="testarJQuery()">Testar jQuery</button>
            <div id="jquery-result"></div>
        </div>

        <!-- Teste 2: Verificar Sessão -->
        <div class="test-section">
            <h3>2. Verificar Sessão PHP</h3>
            <button onclick="verificarSessao()">Verificar Sessão</button>
            <div id="sessao-result"></div>
        </div>

        <!-- Teste 3: Testar Conexão com Banco -->
        <div class="test-section">
            <h3>3. Testar Conexão com Banco de Dados</h3>
            <button onclick="testarBanco()">Testar Banco</button>
            <div id="banco-result"></div>
        </div>

        <!-- Teste 4: Testar carregar_associados.php -->
        <div class="test-section">
            <h3>4. Testar carregar_associados.php</h3>
            <button onclick="testarCarregarAssociados()">Testar Carregamento</button>
            <div id="carregar-result"></div>
            <div class="log" id="ajax-log" style="display:none;">
                <strong>Log de Requisição:</strong>
                <div id="log-content"></div>
            </div>
        </div>

        <!-- Teste 5: Verificar Caminhos -->
        <div class="test-section">
            <h3>5. Verificar Caminhos dos Arquivos</h3>
            <button onclick="verificarCaminhos()">Verificar Caminhos</button>
            <div id="caminhos-result"></div>
        </div>

        <!-- Console de Debug -->
        <div class="test-section">
            <h3>Console de Debug</h3>
            <div class="log" id="debug-console">
                <div id="console-content"></div>
            </div>
            <button onclick="limparConsole()">Limpar Console</button>
        </div>
    </div>

    <script>
        // Função para adicionar log ao console
        function addLog(message, type = 'info') {
            const timestamp = new Date().toLocaleTimeString();
            const logEntry = $('<div>').addClass('log-entry log-' + type)
                .text(`[${timestamp}] ${message}`);
            $('#console-content').append(logEntry);
            $('#debug-console').scrollTop($('#debug-console')[0].scrollHeight);
        }

        // 1. Testar jQuery
        function testarJQuery() {
            const result = $('#jquery-result');
            result.empty();
            
            if (typeof jQuery !== 'undefined') {
                result.html('<div class="status success">✓ jQuery está carregado. Versão: ' + jQuery.fn.jquery + '</div>');
                addLog('jQuery carregado com sucesso', 'success');
            } else {
                result.html('<div class="status error">✗ jQuery não está carregado!</div>');
                addLog('jQuery não encontrado', 'error');
            }
        }

        // 2. Verificar Sessão
        function verificarSessao() {
            const result = $('#sessao-result');
            result.html('<div class="status info">Verificando sessão...</div>');
            
            // Cria um arquivo PHP temporário para verificar sessão
            $.ajax({
                url: '../php/check_session.php',
                method: 'GET',
                dataType: 'json',
                success: function(data) {
                    result.html('<div class="status success">✓ Sessão ativa</div>');
                    result.append('<pre>' + JSON.stringify(data, null, 2) + '</pre>');
                    addLog('Sessão verificada com sucesso', 'success');
                },
                error: function(xhr) {
                    result.html('<div class="status warning">⚠ Criar arquivo check_session.php</div>');
                    result.append(`
                        <p>Crie o arquivo <code>php/check_session.php</code> com o seguinte conteúdo:</p>
                        <pre>&lt;?php
session_start();
header('Content-Type: application/json');
echo json_encode([
    'session_active' => session_status() === PHP_SESSION_ACTIVE,
    'session_id' => session_id(),
    'logged_in' => isset($_SESSION['funcionario_id'])
]);
?&gt;</pre>
                    `);
                    addLog('Arquivo check_session.php não encontrado', 'warning');
                }
            });
        }

        // 3. Testar Banco de Dados
        function testarBanco() {
            const result = $('#banco-result');
            result.html('<div class="status info">Testando conexão com banco...</div>');
            
            $.ajax({
                url: '../php/test_db.php',
                method: 'GET',
                dataType: 'json',
                success: function(data) {
                    if (data.status === 'success') {
                        result.html('<div class="status success">✓ Conexão com banco OK</div>');
                        result.append('<pre>' + JSON.stringify(data, null, 2) + '</pre>');
                        addLog('Banco de dados conectado', 'success');
                    } else {
                        result.html('<div class="status error">✗ Erro na conexão</div>');
                        result.append('<pre>' + data.error + '</pre>');
                        addLog('Erro no banco: ' + data.error, 'error');
                    }
                },
                error: function(xhr) {
                    result.html('<div class="status warning">⚠ Criar arquivo test_db.php</div>');
                    result.append(`
                        <p>Crie o arquivo <code>php/test_db.php</code> com o seguinte conteúdo:</p>
                        <pre>&lt;?php
header('Content-Type: application/json');
try {
    require_once __DIR__ . '/../config/database.php';
    $db = db();
    $test = $db->fetchOne("SELECT 1 as test");
    $count = $db->fetchOne("SELECT COUNT(*) as total FROM Associados");
    echo json_encode([
        'status' => 'success',
        'test_query' => $test,
        'total_associados' => $count['total'] ?? 0
    ]);
} catch (Exception $e) {
    echo json_encode([
        'status' => 'error',
        'error' => $e->getMessage()
    ]);
}
?&gt;</pre>
                    `);
                    addLog('Arquivo test_db.php não encontrado', 'warning');
                }
            });
        }

        // 4. Testar carregar_associados.php
        function testarCarregarAssociados() {
            const result = $('#carregar-result');
            const logDiv = $('#ajax-log');
            const logContent = $('#log-content');
            
            result.html('<div class="status info">Testando carregar_associados.php... <span class="loading">⏳</span></div>');
            logDiv.show();
            logContent.empty();
            
            addLog('Iniciando requisição para carregar_associados.php', 'info');
            
            const startTime = Date.now();
            
            $.ajax({
                url: '../php/carregar_associados.php',
                method: 'GET',
                dataType: 'json',
                timeout: 15000, // 15 segundos
                beforeSend: function(xhr) {
                    logContent.append('<div>→ Enviando requisição GET...</div>');
                },
                success: function(data, textStatus, xhr) {
                    const endTime = Date.now();
                    const duration = endTime - startTime;
                    
                    logContent.append('<div>✓ Resposta recebida em ' + duration + 'ms</div>');
                    logContent.append('<div>Status HTTP: ' + xhr.status + '</div>');
                    logContent.append('<div>Content-Type: ' + xhr.getResponseHeader('Content-Type') + '</div>');
                    
                    if (data.status === 'success') {
                        result.html('<div class="status success">✓ Carregamento OK</div>');
                        result.append('<p>Total de registros: ' + data.total + '</p>');
                        result.append('<p>Registros retornados: ' + (data.dados ? data.dados.length : 0) + '</p>');
                        
                        if (data.dados && data.dados.length > 0) {
                            result.append('<p>Exemplo de registro:</p>');
                            result.append('<pre>' + JSON.stringify(data.dados[0], null, 2) + '</pre>');
                        }
                        
                        addLog('Dados carregados com sucesso: ' + data.total + ' registros', 'success');
                    } else {
                        result.html('<div class="status error">✗ Erro no carregamento</div>');
                        result.append('<pre>' + JSON.stringify(data, null, 2) + '</pre>');
                        addLog('Erro: ' + data.message, 'error');
                    }
                },
                error: function(xhr, textStatus, errorThrown) {
                    const endTime = Date.now();
                    const duration = endTime - startTime;
                    
                    logContent.append('<div style="color: red;">✗ Erro após ' + duration + 'ms</div>');
                    logContent.append('<div>Status: ' + xhr.status + ' ' + xhr.statusText + '</div>');
                    logContent.append('<div>Erro: ' + errorThrown + '</div>');
                    logContent.append('<div>Tipo: ' + textStatus + '</div>');
                    
                    result.html('<div class="status error">✗ Erro na requisição</div>');
                    result.append('<p><strong>Status:</strong> ' + xhr.status + ' ' + xhr.statusText + '</p>');
                    result.append('<p><strong>Erro:</strong> ' + errorThrown + '</p>');
                    
                    if (xhr.responseText) {
                        result.append('<p><strong>Resposta do servidor:</strong></p>');
                        result.append('<pre>' + xhr.responseText.substring(0, 500) + '...</pre>');
                    }
                    
                    addLog('Erro AJAX: ' + xhr.status + ' - ' + errorThrown, 'error');
                    
                    // Dicas baseadas no erro
                    if (xhr.status === 404) {
                        result.append('<div class="status warning">⚠ Arquivo não encontrado. Verifique o caminho.</div>');
                    } else if (xhr.status === 500) {
                        result.append('<div class="status warning">⚠ Erro no servidor. Verifique os logs do PHP.</div>');
                    } else if (textStatus === 'timeout') {
                        result.append('<div class="status warning">⚠ Timeout. A consulta pode estar muito lenta.</div>');
                    } else if (textStatus === 'parsererror') {
                        result.append('<div class="status warning">⚠ Resposta não é JSON válido. Verifique se há saída HTML antes do JSON.</div>');
                    }
                }
            });
        }

        // 5. Verificar Caminhos
        function verificarCaminhos() {
            const result = $('#caminhos-result');
            result.empty();
            
            const arquivos = [
                '../config/database.php',
                '../includes/functions.php',
                '../php/carregar_associados.php',
                '../includes/session_check.php',
                '../.env'
            ];
            
            result.append('<p>Verificando existência dos arquivos...</p>');
            
            arquivos.forEach(function(arquivo) {
                $.ajax({
                    url: arquivo,
                    method: 'HEAD',
                    success: function() {
                        result.append('<div class="status success">✓ ' + arquivo + ' existe</div>');
                        addLog('Arquivo encontrado: ' + arquivo, 'success');
                    },
                    error: function(xhr) {
                        if (xhr.status === 404) {
                            result.append('<div class="status error">✗ ' + arquivo + ' não encontrado</div>');
                            addLog('Arquivo não encontrado: ' + arquivo, 'error');
                        } else {
                            result.append('<div class="status warning">⚠ ' + arquivo + ' (Status: ' + xhr.status + ')</div>');
                        }
                    }
                });
            });
        }

        // Limpar console
        function limparConsole() {
            $('#console-content').empty();
            addLog('Console limpo', 'info');
        }

        // Inicialização
        $(document).ready(function() {
            addLog('Página de debug carregada', 'info');
            testarJQuery();
        });
    </script>
</body>
</html>