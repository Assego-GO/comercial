<?php
session_start();

// Inclui o arquivo de configuração do banco e funções
require_once '../../config/database.php';
require_once '../../includes/functions.php';

// Verifica se a requisição é POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../../login.php');
    exit;
}

// Recebe e sanitiza os dados do formulário
$email = filter_input(INPUT_POST, 'email', FILTER_SANITIZE_EMAIL);
$senha = filter_input(INPUT_POST, 'senha', FILTER_SANITIZE_STRING);

// Validação básica
if (empty($email) || empty($senha)) {
    $_SESSION['erro_login'] = 'Por favor, preencha todos os campos.';
    header('Location: ../../login.php');
    exit;
}

// Valida formato do email
if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    $_SESSION['erro_login'] = 'E-mail inválido.';
    header('Location: ../../login.php');
    exit;
}

try {
    $db = db();
    
    // Busca o funcionário pelo email
    $sql = "SELECT f.id, f.nome, f.email, f.senha, f.senha_alterada_em, f.ativo, 
                   f.departamento_id, f.cargo, f.foto,
                   d.nome as departamento_nome
            FROM Funcionarios f
            LEFT JOIN Departamentos d ON f.departamento_id = d.id
            WHERE f.email = :email
            LIMIT 1";
    
    $funcionario = $db->fetchOne($sql, ['email' => $email]);
    
    if (!$funcionario) {
        // Registra tentativa de login falhada
        registrarLog('LOGIN_FALHA', "Tentativa de login com email não cadastrado: $email");
        
        $_SESSION['erro_login'] = 'E-mail ou senha incorretos.';
        header('Location: ../../login.php');
        exit;
    }
    
    // Verifica se o funcionário está ativo
    if (!$funcionario['ativo']) {
        registrarLog('LOGIN_BLOQUEADO', "Tentativa de login com conta inativa: $email");
        
        $_SESSION['erro_login'] = 'Sua conta está inativa. Entre em contato com o administrador.';
        header('Location: ../../login.php');
        exit;
    }
    
    // Verifica a senha
    if (!password_verify($senha, $funcionario['senha'])) {
        // Registra tentativa de login falhada
        registrarLog('LOGIN_FALHA', "Senha incorreta para o email: $email");
        
        $_SESSION['erro_login'] = 'E-mail ou senha incorretos.';
        header('Location: ../../login.php');
        exit;
    }
    
    // Verifica se a senha precisa ser atualizada (rehash se necessário)
    if (password_needs_rehash($funcionario['senha'], PASSWORD_BCRYPT, ['cost' => 12])) {
        $novoHash = password_hash($senha, PASSWORD_BCRYPT, ['cost' => 12]);
        $db->update('Funcionarios', 
            ['senha' => $novoHash, 'senha_alterada_em' => date('Y-m-d H:i:s')], 
            'id = :id', 
            ['id' => $funcionario['id']]
        );
    }
    
    // Login bem-sucedido - cria a sessão
    $_SESSION['funcionario_id'] = $funcionario['id'];
    $_SESSION['funcionario_nome'] = $funcionario['nome'];
    $_SESSION['funcionario_email'] = $funcionario['email'];
    $_SESSION['funcionario_cargo'] = $funcionario['cargo'];
    $_SESSION['funcionario_foto'] = $funcionario['foto'];
    $_SESSION['departamento_id'] = $funcionario['departamento_id'];
    $_SESSION['departamento_nome'] = $funcionario['departamento_nome'];
    $_SESSION['login_time'] = time();
    $_SESSION['last_activity'] = time();
    
    // Busca as permissões do funcionário
    $sqlPermissoes = "SELECT DISTINCT recurso_chave, permissao_nome 
                      FROM vw_permissoes_efetivas 
                      WHERE funcionario_id = :funcionario_id 
                      AND tem_permissao = 1";
    
    $permissoes = $db->fetchAll($sqlPermissoes, ['funcionario_id' => $funcionario['id']]);
    
    // Armazena as permissões na sessão para acesso rápido
    $_SESSION['permissoes'] = [];
    foreach ($permissoes as $permissao) {
        if (!isset($_SESSION['permissoes'][$permissao['recurso_chave']])) {
            $_SESSION['permissoes'][$permissao['recurso_chave']] = [];
        }
        $_SESSION['permissoes'][$permissao['recurso_chave']][] = $permissao['permissao_nome'];
    }
    
    // Regenera o ID da sessão por segurança
    session_regenerate_id(true);
    
    // Registra o login bem-sucedido
    registrarLog('LOGIN_SUCESSO', "Login realizado com sucesso", $funcionario['id']);
    
    // Verifica se o funcionário precisa alterar a senha (primeira vez ou expirada)
    $diasDesdeAlteracao = 90; // Senha expira em 90 dias
    if (!empty($funcionario['senha_alterada_em'])) {
        $dataAlteracao = new DateTime($funcionario['senha_alterada_em']);
        $hoje = new DateTime();
        $intervalo = $dataAlteracao->diff($hoje);
        
        if ($intervalo->days >= $diasDesdeAlteracao) {
            $_SESSION['senha_expirada'] = true;
            $_SESSION['sucesso_login'] = 'Login realizado com sucesso! Sua senha expirou, por favor altere-a.';
            header('Location: ../../alterar_senha.php');
            exit;
        }
    } else {
        // Primeira vez logando
        $_SESSION['primeiro_acesso'] = true;
        $_SESSION['sucesso_login'] = 'Bem-vindo! Por favor, defina uma nova senha.';
        header('Location: ../../alterar_senha.php');
        exit;
    }
    
    // Redireciona para a página principal
    header('Location: ../associados_list.php');
    exit;
    
} catch (Exception $e) {
    // Log do erro
    error_log("Erro no login: " . $e->getMessage());
    registrarLog('LOGIN_ERRO', "Erro no sistema: " . $e->getMessage());
    
    $_SESSION['erro_login'] = 'Ocorreu um erro no sistema. Por favor, tente novamente.';
    header('Location: ../../login.php');
    exit;
}
?>