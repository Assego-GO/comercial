<?php
session_start();

// Inclui as funções para registrar o log
require_once '../../includes/functions.php';

// Registra o logout se houver usuário logado
if (isset($_SESSION['funcionario_id'])) {
    registrarLog('LOGOUT', 'Logout realizado', $_SESSION['funcionario_id']);
}

// Remove todas as variáveis de sessão
$_SESSION = array();

// Destrói o cookie de sessão
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// Destrói a sessão
session_destroy();

// Define mensagem de sucesso
session_start();
$_SESSION['sucesso_login'] = 'Logout realizado com sucesso!';

// Redireciona para a página de login
header('Location: ../../login.php');
exit;
?>