<?php
// Script para debug de valores do associado
require_once '../includes/session_check.php';
require_once '../config/database.php';

header('Content-Type: text/plain; charset=utf-8');

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($id === 0) {
    die("Por favor, forneça um ID: debug_associado.php?id=123");
}

try {
    $db = db();
    
    // Busca completa do associado
    $sql = "SELECT 
                a.id,
                a.nome,
                a.estadoCivil,
                a.escolaridade,
                a.situacao,
                m.corporacao,
                m.categoria,
                f.tipoAssociado,
                f.situacaoFinanceira,
                f.localDebito
            FROM Associados a
            LEFT JOIN Militar m ON a.id = m.associado_id
            LEFT JOIN Financeiro f ON a.id = f.associado_id
            WHERE a.id = ?";
    
    $dados = $db->fetchOne($sql, [$id]);
    
    if (!$dados) {
        die("Associado não encontrado!");
    }
    
    echo "=== DEBUG ASSOCIADO ID: $id ===\n\n";
    echo "Nome: " . $dados['nome'] . "\n\n";
    
    echo "CAMPOS PROBLEMÁTICOS:\n";
    echo "-------------------\n";
    
    // Estado Civil
    echo "Estado Civil:\n";
    echo "  Valor no banco: " . var_export($dados['estadoCivil'], true) . "\n";
    echo "  Tamanho: " . strlen($dados['estadoCivil'] ?? '') . "\n";
    echo "  Hexadecimal: " . bin2hex($dados['estadoCivil'] ?? '') . "\n\n";
    
    // Escolaridade
    echo "Escolaridade:\n";
    echo "  Valor no banco: " . var_export($dados['escolaridade'], true) . "\n";
    echo "  Tamanho: " . strlen($dados['escolaridade'] ?? '') . "\n";
    echo "  Hexadecimal: " . bin2hex($dados['escolaridade'] ?? '') . "\n\n";
    
    // Corporação
    echo "Corporação:\n";
    echo "  Valor no banco: " . var_export($dados['corporacao'], true) . "\n";
    echo "  Tamanho: " . strlen($dados['corporacao'] ?? '') . "\n";
    echo "  Hexadecimal: " . bin2hex($dados['corporacao'] ?? '') . "\n\n";
    
    // Tipo Associado
    echo "Tipo Associado:\n";
    echo "  Valor no banco: " . var_export($dados['tipoAssociado'], true) . "\n";
    echo "  Tamanho: " . strlen($dados['tipoAssociado'] ?? '') . "\n";
    echo "  Hexadecimal: " . bin2hex($dados['tipoAssociado'] ?? '') . "\n\n";
    
    // Outros campos que podem ter problemas
    echo "OUTROS CAMPOS:\n";
    echo "--------------\n";
    
    echo "Situação: " . var_export($dados['situacao'], true) . "\n";
    echo "Categoria: " . var_export($dados['categoria'], true) . "\n";
    echo "Situação Financeira: " . var_export($dados['situacaoFinanceira'], true) . "\n";
    echo "Local Débito: " . var_export($dados['localDebito'], true) . "\n\n";
    
    // Verifica valores únicos de cada campo
    echo "VALORES ÚNICOS NO BANCO:\n";
    echo "------------------------\n";
    
    $campos = [
        'Associados.estadoCivil' => 'Estado Civil',
        'Associados.escolaridade' => 'Escolaridade',
        'Militar.corporacao' => 'Corporação',
        'Financeiro.tipoAssociado' => 'Tipo Associado'
    ];
    
    foreach ($campos as $campo => $label) {
        list($tabela, $coluna) = explode('.', $campo);
        $valores = $db->fetchAll("SELECT DISTINCT $coluna as valor, COUNT(*) as total FROM $tabela WHERE $coluna IS NOT NULL AND $coluna != '' GROUP BY $coluna ORDER BY total DESC LIMIT 10");
        
        echo "\n$label:\n";
        foreach ($valores as $v) {
            echo "  - " . var_export($v['valor'], true) . " (usado " . $v['total'] . " vezes)\n";
        }
    }
    
} catch (Exception $e) {
    echo "Erro: " . $e->getMessage();
}
?>