<?php
// Evita que erros quebrem o JSON
error_reporting(0);
ini_set('display_errors', 0);

// Inicia a sessão se ainda não foi iniciada
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Define o cabeçalho como JSON desde o início
header('Content-Type: application/json; charset=utf-8');

// Resposta padrão
$response = [
    'status' => 'error',
    'message' => '',
    'dados' => [],
    'total' => 0
];

try {
    // Inclui os arquivos necessários
    require_once __DIR__ . '/../config/database.php';
    require_once __DIR__ . '/../includes/functions.php';
    
    // Obtém a instância do banco de dados
    $db = db();
    
    // Query para buscar os associados com TODAS as informações relacionadas
    $query = "
        SELECT 
            a.id,
            a.nome,
            a.nasc,
            a.sexo,
            a.cpf,
            a.rg,
            a.telefone,
            a.email,
            a.foto,
            a.escolaridade,
            a.estadoCivil,
            a.indicacao,
            COALESCE(a.situacao, 'Filiado') as situacao,
            m.corporacao,
            m.patente,
            m.categoria,
            m.lotacao,
            m.unidade,
            c.dataFiliacao as data_filiacao,
            c.dataDesfiliacao as data_desfiliacao,
            e.cep,
            e.endereco,
            e.numero,
            e.complemento,
            e.bairro,
            e.cidade,
            f.tipoAssociado,
            f.situacaoFinanceira,
            f.vinculoServidor,
            f.localDebito,
            f.agencia,
            f.operacao,
            f.contaCorrente
        FROM Associados a
        LEFT JOIN Militar m ON a.id = m.associado_id
        LEFT JOIN Contrato c ON a.id = c.associado_id
        LEFT JOIN Endereco e ON a.id = e.associado_id
        LEFT JOIN Financeiro f ON a.id = f.associado_id
        ORDER BY a.id DESC
    ";
    
    // Executa a query para buscar os associados
    $associados = $db->fetchAll($query);
    
    // Conta o total de registros
    $totalQuery = "SELECT COUNT(*) as total FROM Associados";
    $totalResult = $db->fetchOne($totalQuery);
    $total = $totalResult['total'] ?? 0;
    
    // Processa os dados dos associados
    $dadosProcessados = [];
    if ($associados) {
        foreach ($associados as $associado) {
            $associadoId = (int)$associado['id'];
            
            // Busca dependentes
            $dependentesQuery = "
                SELECT nome, data_nascimento, parentesco, sexo 
                FROM Dependentes 
                WHERE associado_id = :id
                ORDER BY nome
            ";
            $dependentes = $db->fetchAll($dependentesQuery, ['id' => $associadoId]);
            
            // Busca redes sociais
            $redesQuery = "
                SELECT nome_rede, usuario 
                FROM Redes_sociais 
                WHERE associado_id = :id
                ORDER BY nome_rede
            ";
            $redesSociais = $db->fetchAll($redesQuery, ['id' => $associadoId]);
            
            // Busca documentos
            $documentosQuery = "
                SELECT tipo_documento, nome_arquivo, data_upload, verificado 
                FROM Documentos_Associado 
                WHERE associado_id = :id
                ORDER BY data_upload DESC
            ";
            $documentos = $db->fetchAll($documentosQuery, ['id' => $associadoId]);
            
            // Busca serviços ativos
            $servicosQuery = "
                SELECT 
                    s.nome as servico_nome,
                    sa.valor_aplicado,
                    sa.data_adesao,
                    sa.ativo
                FROM Servicos_Associado sa
                JOIN Servicos s ON sa.servico_id = s.id
                WHERE sa.associado_id = :id AND sa.ativo = 1
                ORDER BY s.nome
            ";
            $servicos = $db->fetchAll($servicosQuery, ['id' => $associadoId]);
            
            // Processa cada campo
            $dadosProcessados[] = [
                'id' => $associadoId,
                'nome' => $associado['nome'] ?? '',
                'nasc' => $associado['nasc'] ?? '',
                'sexo' => $associado['sexo'] ?? '',
                'cpf' => $associado['cpf'] ?? '',
                'rg' => $associado['rg'] ?? '',
                'telefone' => $associado['telefone'] ?? '',
                'email' => $associado['email'] ?? '',
                'foto' => $associado['foto'] ?? '',
                'escolaridade' => $associado['escolaridade'] ?? '',
                'estadoCivil' => $associado['estadoCivil'] ?? '',
                'indicacao' => $associado['indicacao'] ?? '',
                'situacao' => $associado['situacao'] ?? 'Filiado',
                
                // Dados militares
                'corporacao' => $associado['corporacao'] ?? '',
                'patente' => $associado['patente'] ?? '',
                'categoria' => $associado['categoria'] ?? '',
                'lotacao' => $associado['lotacao'] ?? '',
                'unidade' => $associado['unidade'] ?? '',
                
                // Datas
                'data_filiacao' => $associado['data_filiacao'] ?? '',
                'data_desfiliacao' => $associado['data_desfiliacao'] ?? '',
                
                // Endereço
                'cep' => $associado['cep'] ?? '',
                'endereco' => $associado['endereco'] ?? '',
                'numero' => $associado['numero'] ?? '',
                'complemento' => $associado['complemento'] ?? '',
                'bairro' => $associado['bairro'] ?? '',
                'cidade' => $associado['cidade'] ?? '',
                
                // Dados financeiros
                'tipoAssociado' => $associado['tipoAssociado'] ?? '',
                'situacaoFinanceira' => $associado['situacaoFinanceira'] ?? '',
                'vinculoServidor' => $associado['vinculoServidor'] ?? '',
                'localDebito' => $associado['localDebito'] ?? '',
                'agencia' => $associado['agencia'] ?? '',
                'operacao' => $associado['operacao'] ?? '',
                'contaCorrente' => $associado['contaCorrente'] ?? '',
                
                // Dados adicionais
                'dependentes' => $dependentes,
                'redesSociais' => $redesSociais,
                'documentos' => $documentos,
                'servicos' => $servicos
            ];
        }
    }
    
    // Prepara a resposta de sucesso
    $response['status'] = 'success';
    $response['dados'] = $dadosProcessados;
    $response['total'] = $total;
    $response['message'] = 'Dados carregados com sucesso';
    
} catch (PDOException $e) {
    // Erro específico de banco de dados
    $response['status'] = 'error';
    $response['message'] = 'Erro ao acessar o banco de dados: ' . $e->getMessage();
    
} catch (Exception $e) {
    // Outros erros
    $response['status'] = 'error';
    $response['message'] = 'Erro: ' . $e->getMessage();
}

// Retorna a resposta em JSON
echo json_encode($response, JSON_UNESCAPED_UNICODE);
exit;