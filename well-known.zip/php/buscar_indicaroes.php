<?php
// Inclui verificação de sessão
require_once '../includes/session_check.php';
require_once '../config/database.php';

// Define o header como JSON
header('Content-Type: application/json');

try {
    $db = db();
    
    // Verifica se é busca por populares ou por query
    $showPopular = isset($_GET['popular']) && $_GET['popular'] == '1';
    $query = isset($_GET['q']) ? trim($_GET['q']) : '';
    
    if ($showPopular) {
        // Busca os 10 indicadores mais frequentes
        $sql = "SELECT 
                    TRIM(indicacao) as nome,
                    COUNT(*) as count
                FROM Associados 
                WHERE indicacao IS NOT NULL 
                    AND indicacao != ''
                GROUP BY LOWER(TRIM(indicacao))
                ORDER BY count DESC, nome ASC
                LIMIT 10";
        
        $results = $db->fetchAll($sql);
    } else {
        // Se não tiver query suficiente, retorna vazio
        if (strlen($query) < 2) {
            echo json_encode([]);
            exit;
        }
        
        // Busca indicadores que contenham o termo
        $sql = "SELECT 
                    TRIM(indicacao) as nome,
                    COUNT(*) as count
                FROM Associados 
                WHERE indicacao IS NOT NULL 
                    AND indicacao != ''
                    AND LOWER(indicacao) LIKE LOWER(?)
                GROUP BY LOWER(TRIM(indicacao))
                ORDER BY count DESC, nome ASC
                LIMIT 10";
        
        $results = $db->fetchAll($sql, ['%' . $query . '%']);
    }
    
    // Processa os resultados para padronizar a capitalização
    $processedResults = [];
    $processedNames = []; // Para controlar duplicatas
    
    foreach ($results as $result) {
        // Capitaliza corretamente o nome (primeira letra de cada palavra)
        $nome = ucwords(strtolower(trim($result['nome'])));
        $nomeLower = strtolower($nome);
        
        // Verifica se já existe um resultado similar
        if (isset($processedNames[$nomeLower])) {
            // Se encontrar similar, soma as contagens
            $index = $processedNames[$nomeLower];
            $processedResults[$index]['count'] += $result['count'];
        } else {
            // Adiciona novo resultado
            $processedNames[$nomeLower] = count($processedResults);
            $processedResults[] = [
                'nome' => $nome,
                'count' => intval($result['count'])
            ];
        }
    }
    
    // Ordena novamente por contagem após processar
    usort($processedResults, function($a, $b) {
        if ($a['count'] == $b['count']) {
            return strcasecmp($a['nome'], $b['nome']);
        }
        return $b['count'] - $a['count'];
    });
    
    echo json_encode(array_values($processedResults));
    
} catch (Exception $e) {
    error_log("Erro ao buscar indicadores: " . $e->getMessage());
    echo json_encode([]);
}
?>