<?php
// Inclui verificação de sessão
require_once '../includes/session_check.php';
require_once '../config/database.php';

// Define o título da página
$page_title = 'Cadastro de Associado - ASSEGO';

// Verifica se é edição
$isEdicao = false;
$associadoId = null;
$dadosAssociado = null;

if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    $isEdicao = true;
    $associadoId = (int)$_GET['id'];
    
    try {
        $db = db();
        
        // Busca dados do associado
        $sql = "SELECT 
                    a.*,
                    e.cep, e.endereco, e.numero, e.complemento, e.bairro, e.cidade,
                    m.corporacao, m.patente, m.categoria, m.unidade, m.lotacao,
                    f.tipoAssociado, f.situacaoFinanceira, f.vinculoServidor, 
                    f.localDebito, f.agencia, f.operacao, f.contaCorrente,
                    c.dataFiliacao, c.dataDesfiliacao
                FROM Associados a
                LEFT JOIN Endereco e ON a.id = e.associado_id
                LEFT JOIN Militar m ON a.id = m.associado_id
                LEFT JOIN Financeiro f ON a.id = f.associado_id
                LEFT JOIN Contrato c ON a.id = c.associado_id
                WHERE a.id = ?";
        
        // Debug da query
        error_log("=== DEBUG QUERY SQL ===");
        error_log("Query: " . preg_replace('/\s+/', ' ', $sql));
        error_log("Associado ID: " . $associadoId);
        
        $dadosAssociado = $db->fetchOne($sql, [$associadoId]);
        
        if (!$dadosAssociado) {
            header('Location: index.php');
            exit;
        }
        
        // Garante que existe registro na tabela Financeiro
        if ($isEdicao && empty($dadosAssociado['tipoAssociado'])) {
            // Verifica se existe registro
            $sqlCheck = "SELECT COUNT(*) as total FROM Financeiro WHERE associado_id = ?";
            $check = $db->fetchOne($sqlCheck, [$associadoId]);
            
            if ($check['total'] == 0) {
                // Cria registro padrão
                $sqlInsert = "INSERT INTO Financeiro (associado_id, tipoAssociado, situacaoFinanceira) VALUES (?, 'Contribuinte', 'Adiplente')";
                $db->execute($sqlInsert, [$associadoId]);
                $dadosAssociado['tipoAssociado'] = 'Contribuinte';
                $dadosAssociado['situacaoFinanceira'] = 'Adiplente';
            } else {
                // Busca novamente
                $sqlTipo = "SELECT tipoAssociado, situacaoFinanceira FROM Financeiro WHERE associado_id = ?";
                $financeiro = $db->fetchOne($sqlTipo, [$associadoId]);
                if ($financeiro) {
                    $dadosAssociado['tipoAssociado'] = $financeiro['tipoAssociado'] ?? 'Contribuinte';
                    $dadosAssociado['situacaoFinanceira'] = $financeiro['situacaoFinanceira'] ?? 'Adiplente';
                }
            }
        }
        
        // Verificação adicional: Existe registro na tabela Financeiro?
        $sqlVerifica = "SELECT COUNT(*) as total FROM Financeiro WHERE associado_id = ?";
        $verificaFinanceiro = $db->fetchOne($sqlVerifica, [$associadoId]);
        error_log("Existe registro em Financeiro? " . ($verificaFinanceiro['total'] > 0 ? "SIM (Total: " . $verificaFinanceiro['total'] . ")" : "NÃO"));
        
        // Se não existir registro em Financeiro, tipoAssociado virá NULL
        if ($verificaFinanceiro['total'] == 0) {
            error_log("AVISO: Não existe registro na tabela Financeiro para o associado ID: " . $associadoId);
        }
        if ($isEdicao && empty($dadosAssociado['tipoAssociado'])) {
            error_log("AVISO: tipoAssociado veio vazio. Buscando diretamente...");
            
            $sqlTipo = "SELECT tipoAssociado FROM Financeiro WHERE associado_id = ?";
            $resultTipo = $db->fetchOne($sqlTipo, [$associadoId]);
            
            if ($resultTipo && !empty($resultTipo['tipoAssociado'])) {
                $dadosAssociado['tipoAssociado'] = $resultTipo['tipoAssociado'];
                error_log("tipoAssociado recuperado: '" . $dadosAssociado['tipoAssociado'] . "'");
            } else {
                error_log("ERRO: Não foi possível recuperar tipoAssociado do banco");
            }
        }
        error_log("=== DADOS DIRETO DO BANCO ===");
        error_log("Carregando dados do associado ID: $associadoId");
        error_log("tipoAssociado do banco: '" . ($dadosAssociado['tipoAssociado'] ?? 'NULL') . "'");
        error_log("Length: " . strlen($dadosAssociado['tipoAssociado'] ?? ''));
        error_log("Hex: " . bin2hex($dadosAssociado['tipoAssociado'] ?? ''));
        
        // Debug todos os campos financeiros
        error_log("--- Campos Financeiros ---");
        error_log("tipoAssociado: '" . ($dadosAssociado['tipoAssociado'] ?? 'NULL') . "'");
        error_log("situacaoFinanceira: '" . ($dadosAssociado['situacaoFinanceira'] ?? 'NULL') . "'");
        error_log("vinculoServidor: '" . ($dadosAssociado['vinculoServidor'] ?? 'NULL') . "'");
        error_log("localDebito: '" . ($dadosAssociado['localDebito'] ?? 'NULL') . "'");
        
        // Verifica se o campo existe no array
        error_log("Campo 'tipoAssociado' existe no array? " . (array_key_exists('tipoAssociado', $dadosAssociado) ? 'SIM' : 'NÃO'));
        
        error_log("=============================");
        
        // Mapeamento de valores antigos para novos
        $mapeamentos = [
            'estadoCivil' => [
                'Solteiro(a)' => 'Solteiro',
                'Casado(a)' => 'Casado',
                'Divorciado(a)' => 'Divorciado',
                'Viuvo(a)' => 'Viúvo',
                'Viúvo(a)' => 'Viúvo',
                'Uniao estavel' => 'União Estável',
                'União estável' => 'União Estável',
                'Separado(a)' => 'Divorciado',
                'Outros' => ''
            ],
            'escolaridade' => [
                'Ensino Medio' => 'Médio Completo',
                'Ensino Médio' => 'Médio Completo',
                'Superior Completo' => 'Superior Completo',
                'Superior Incompleto' => 'Superior Incompleto',
                'Fundamental Completo' => 'Fundamental Completo',
                'Mestre(a)' => 'Mestrado',
                'escolaridade' => '', // Caso tenha o texto 'escolaridade' no banco
                '' => '' // Mantém vazio se estiver vazio
            ],
            'corporacao' => [
                'Policia Militar' => 'Polícia Militar',
                'Bombeiro Militar' => 'Bombeiro Militar',
                'Agregados' => 'Agregado',
                'Pensionista' => 'Civil',
                'Exercito' => 'Exército',
                'Outros' => 'Civil',
                'Civil' => 'Civil'
            ],
            'situacaoFinanceira' => [
                'Adiplente' => 'Adiplente',
                'Inadiplente' => 'Inadiplente',
                'Adimplente' => 'Adiplente',
                'Inadimplente' => 'Inadiplente'
            ],
            'tipoAssociado' => [
                'Ativa' => 'Contribuinte',
                'Reserva' => 'Contribuinte',
                'Pensionista' => 'Remido',
                'Afastado' => 'Contribuinte',
                'Contribuinte' => 'Contribuinte',
                'Agregado' => 'Agregado',
                'Benemerito' => 'Benemerito',
                'Remido' => 'Remido',
                'Remido 50%' => 'Remido 50%'
            ]
        ];
        
        // Função para mapear valores do banco para o formulário
        function mapearValor($campo, $valorBanco, $mapeamentos) {
            if ($valorBanco === null) return '';
            
            // Se o campo tem mapeamento definido
            if (isset($mapeamentos[$campo])) {
                $valorNormalizado = trim($valorBanco);
                
                // Procura correspondência exata primeiro
                if (isset($mapeamentos[$campo][$valorNormalizado])) {
                    return $mapeamentos[$campo][$valorNormalizado];
                }
                
                // Tenta correspondência case-insensitive
                foreach ($mapeamentos[$campo] as $antigo => $novo) {
                    if (strcasecmp($antigo, $valorNormalizado) === 0) {
                        return $novo;
                    }
                }
            }
            
            return $valorBanco;
        }
        
        // Aplica os mapeamentos aos dados do associado
        if ($dadosAssociado) {
            // Faz o mapeamento de todos os campos
            $dadosAssociado['estadoCivil'] = mapearValor('estadoCivil', $dadosAssociado['estadoCivil'], $mapeamentos);
            $dadosAssociado['escolaridade'] = mapearValor('escolaridade', $dadosAssociado['escolaridade'], $mapeamentos);
            $dadosAssociado['corporacao'] = mapearValor('corporacao', $dadosAssociado['corporacao'], $mapeamentos);
            $dadosAssociado['situacaoFinanceira'] = mapearValor('situacaoFinanceira', $dadosAssociado['situacaoFinanceira'], $mapeamentos);
            
            // Para tipoAssociado, só mapeia se não for um valor válido
            $valoresTipoValidos = ['Contribuinte', 'Agregado', 'Benemerito', 'Remido', 'Remido 50%'];
            if (!in_array($dadosAssociado['tipoAssociado'], $valoresTipoValidos)) {
                $dadosAssociado['tipoAssociado'] = mapearValor('tipoAssociado', $dadosAssociado['tipoAssociado'], $mapeamentos);
            }
        }
        
        // Busca dependentes
        $dependentes = $db->fetchAll(
            "SELECT * FROM Dependentes WHERE associado_id = ? ORDER BY id",
            [$associadoId]
        );
        
        // Busca redes sociais
        $redesSociais = $db->fetchAll(
            "SELECT * FROM Redes_sociais WHERE associado_id = ? ORDER BY id",
            [$associadoId]
        );
        
        // Busca serviços do associado
        $servicosAssociado = $db->fetchAll(
            "SELECT sa.*, s.nome as servico_nome, s.valor_base 
             FROM Servicos_Associado sa 
             JOIN Servicos s ON sa.servico_id = s.id 
             WHERE sa.associado_id = ? AND sa.ativo = 1",
            [$associadoId]
        );
        
    } catch (Exception $e) {
        error_log("Erro ao buscar associado: " . $e->getMessage());
        header('Location: index.php');
        exit;
    }
}

// Função helper para comparar valores de select
function isSelected($valorBanco, $valorOpcao) {
    // Se ambos são vazios ou nulos, retorna false
    if ((empty($valorBanco) || $valorBanco === null) && (empty($valorOpcao) || $valorOpcao === null)) {
        return false;
    }
    
    // Se um é vazio/nulo e outro não, retorna false
    if ((empty($valorBanco) || $valorBanco === null) !== (empty($valorOpcao) || $valorOpcao === null)) {
        return false;
    }
    
    // Comparação direta primeiro (mais eficiente)
    if (trim($valorBanco) === trim($valorOpcao)) {
        return true;
    }
    
    // Remove espaços e converte para lowercase
    $valorBanco = trim(strtolower((string)$valorBanco));
    $valorOpcao = trim(strtolower((string)$valorOpcao));
    
    // Comparação exata após normalização
    if ($valorBanco === $valorOpcao) {
        return true;
    }
    
    // Remove acentos e compara novamente
    $valorBancoSemAcento = removeAcentos($valorBanco);
    $valorOpcaoSemAcento = removeAcentos($valorOpcao);
    
    if ($valorBancoSemAcento === $valorOpcaoSemAcento) {
        return true;
    }
    
    // Comparações específicas para casos conhecidos
    $comparacoes = [
        // Estado Civil
        ['banco' => 'solteiro(a)', 'opcao' => 'solteiro'],
        ['banco' => 'casado(a)', 'opcao' => 'casado'],
        ['banco' => 'divorciado(a)', 'opcao' => 'divorciado'],
        ['banco' => 'viuvo(a)', 'opcao' => 'viuvo'],
        ['banco' => 'viuvo(a)', 'opcao' => 'viúvo'],
        ['banco' => 'uniao estavel', 'opcao' => 'uniao estavel'],
        ['banco' => 'uniao estavel', 'opcao' => 'união estável'],
        ['banco' => 'separado(a)', 'opcao' => 'divorciado'],
        
        // Corporação
        ['banco' => 'policia militar', 'opcao' => 'policia militar'],
        ['banco' => 'policia militar', 'opcao' => 'polícia militar'],
        ['banco' => 'agregados', 'opcao' => 'agregado'],
        ['banco' => 'exercito', 'opcao' => 'exercito'],
        ['banco' => 'exercito', 'opcao' => 'exército'],
        ['banco' => 'pensionista', 'opcao' => 'civil'],
        ['banco' => 'outros', 'opcao' => 'civil'],
        
        // Escolaridade
        ['banco' => 'ensino medio', 'opcao' => 'medio completo'],
        ['banco' => 'ensino medio', 'opcao' => 'médio completo'],
        ['banco' => 'mestre(a)', 'opcao' => 'mestrado'],
        
        // Situação Financeira
        ['banco' => 'adiplente', 'opcao' => 'adiplente'],
        ['banco' => 'inadiplente', 'opcao' => 'inadiplente'],
        ['banco' => 'adimplente', 'opcao' => 'adiplente'],
        ['banco' => 'inadimplente', 'opcao' => 'inadiplente'],
        
        // Tipo Associado - casos especiais
        ['banco' => 'ativa', 'opcao' => 'contribuinte'],
        ['banco' => 'reserva', 'opcao' => 'contribuinte'],
        ['banco' => 'pensionista', 'opcao' => 'remido'],
        ['banco' => 'afastado', 'opcao' => 'contribuinte'],
        ['banco' => 'benemerito', 'opcao' => 'benemerito'],
        ['banco' => 'remido 50%', 'opcao' => 'remido 50%']
    ];
    
    foreach ($comparacoes as $comp) {
        if ($valorBancoSemAcento === $comp['banco'] && $valorOpcaoSemAcento === $comp['opcao']) {
            return true;
        }
    }
    
    return false;
}

// Função para remover acentos
function removeAcentos($str) {
    $acentos = array(
        'á' => 'a', 'à' => 'a', 'ã' => 'a', 'â' => 'a', 'ä' => 'a',
        'é' => 'e', 'è' => 'e', 'ê' => 'e', 'ë' => 'e',
        'í' => 'i', 'ì' => 'i', 'î' => 'i', 'ï' => 'i',
        'ó' => 'o', 'ò' => 'o', 'õ' => 'o', 'ô' => 'o', 'ö' => 'o',
        'ú' => 'u', 'ù' => 'u', 'û' => 'u', 'ü' => 'u',
        'ç' => 'c',
        'Á' => 'A', 'À' => 'A', 'Ã' => 'A', 'Â' => 'A', 'Ä' => 'A',
        'É' => 'E', 'È' => 'E', 'Ê' => 'E', 'Ë' => 'E',
        'Í' => 'I', 'Ì' => 'I', 'Î' => 'I', 'Ï' => 'I',
        'Ó' => 'O', 'Ò' => 'O', 'Õ' => 'O', 'Ô' => 'O', 'Ö' => 'O',
        'Ú' => 'U', 'Ù' => 'U', 'Û' => 'U', 'Ü' => 'U',
        'Ç' => 'C'
    );
    
    return strtr($str, $acentos);
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $page_title; ?></title>

    <!-- Favicon -->
    <link rel="icon" href="../assets/img/favicon.ico" type="image/x-icon">

    <!-- Bootstrap 5 CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Font Awesome Pro -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">

    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>

    <!-- jQuery Mask Plugin -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>

    <!-- SweetAlert2 -->
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

    <!-- Custom CSS -->
    <style>
        :root {
            --primary: #0056D2;
            --primary-dark: #003A8C;
            --primary-light: #E8F1FF;
            --secondary: #FFB800;
            --secondary-dark: #CC9200;
            --success: #00C853;
            --danger: #FF3B30;
            --warning: #FF9500;
            --info: #00B8D4;
            --dark: #1C1C1E;
            --gray-100: #F7F7F7;
            --gray-200: #E5E5E7;
            --gray-300: #D1D1D6;
            --gray-400: #C7C7CC;
            --gray-500: #8E8E93;
            --gray-600: #636366;
            --gray-700: #48484A;
            --gray-800: #3A3A3C;
            --gray-900: #2C2C2E;
            --white: #FFFFFF;
            
            --header-height: 70px;
            
            --shadow-sm: 0 1px 3px rgba(0,0,0,0.08);
            --shadow-md: 0 4px 6px rgba(0,0,0,0.12), 0 2px 4px rgba(0,0,0,0.24);
            --shadow-lg: 0 10px 20px rgba(0,0,0,0.12), 0 4px 8px rgba(0,0,0,0.24);
            --shadow-xl: 0 20px 40px rgba(0,0,0,0.12), 0 8px 16px rgba(0,0,0,0.24);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Plus Jakarta Sans', -apple-system, BlinkMacSystemFont, sans-serif;
            background-color: var(--gray-100);
            color: var(--dark);
            overflow-x: hidden;
        }

        /* Scrollbar personalizada */
        ::-webkit-scrollbar {
            width: 6px;
            height: 6px;
        }

        ::-webkit-scrollbar-track {
            background: var(--gray-100);
        }

        ::-webkit-scrollbar-thumb {
            background: var(--gray-400);
            border-radius: 3px;
        }

        ::-webkit-scrollbar-thumb:hover {
            background: var(--gray-500);
        }

        /* Main Content */
        .main-wrapper {
            min-height: 100vh;
            background: var(--gray-100);
        }

        /* Header */
        .main-header {
            background: var(--white);
            height: var(--header-height);
            padding: 0 2rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            box-shadow: var(--shadow-sm);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .header-left {
            display: flex;
            align-items: center;
            gap: 2rem;
        }

        .logo-section {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .logo-text {
            color: var(--primary);
            font-size: 1.5rem;
            font-weight: 800;
            margin: 0;
            letter-spacing: -0.5px;
        }

        .system-subtitle {
            color: var(--gray-500);
            font-size: 0.875rem;
            margin: 0;
            font-weight: 500;
        }

        .header-right {
            display: flex;
            align-items: center;
            gap: 1rem;
        }

        .header-btn {
            width: 40px;
            height: 40px;
            border: none;
            background: var(--gray-100);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.2s ease;
            position: relative;
            color: var(--gray-600);
        }

        .header-btn:hover {
            background: var(--primary-light);
            color: var(--primary);
        }

        .user-menu {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.5rem;
            background: var(--gray-100);
            border-radius: 12px;
            cursor: pointer;
            transition: all 0.2s ease;
            position: relative;
        }

        .user-menu:hover {
            background: var(--gray-200);
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            background: var(--primary);
            color: var(--white);
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 600;
        }

        .user-info {
            text-align: right;
        }

        .user-name {
            font-weight: 600;
            font-size: 0.875rem;
            color: var(--dark);
            margin: 0;
        }

        .user-role {
            font-size: 0.75rem;
            color: var(--gray-500);
            margin: 0;
        }

        /* Dropdown Menu */
        .dropdown-menu-custom {
            position: absolute;
            top: calc(100% + 10px);
            right: 0;
            background: var(--white);
            border-radius: 12px;
            box-shadow: var(--shadow-lg);
            min-width: 200px;
            padding: 0.5rem;
            opacity: 0;
            visibility: hidden;
            transform: translateY(-10px);
            transition: all 0.3s ease;
            z-index: 1000;
        }

        .dropdown-menu-custom.show {
            opacity: 1;
            visibility: visible;
            transform: translateY(0);
        }

        .dropdown-item-custom {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 0.75rem 1rem;
            border-radius: 8px;
            color: var(--gray-700);
            text-decoration: none;
            transition: all 0.2s ease;
        }

        .dropdown-item-custom:hover {
            background: var(--gray-100);
            color: var(--primary);
        }

        .dropdown-divider-custom {
            height: 1px;
            background: var(--gray-200);
            margin: 0.5rem 0;
        }

        /* Content Area */
        .content-area {
            padding: 2rem;
        }

        /* Page Header */
        .page-header {
            margin-bottom: 2rem;
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 1rem;
        }

        .page-title {
            font-size: 2rem;
            font-weight: 800;
            color: var(--dark);
            margin: 0;
        }

        .page-subtitle {
            font-size: 1rem;
            color: var(--gray-600);
            margin: 0.25rem 0 0 0;
        }

        .page-actions {
            display: flex;
            gap: 0.75rem;
        }

        /* Tabs Navigation */
        .nav-tabs-custom {
            display: flex;
            gap: 1rem;
            border-bottom: 2px solid var(--gray-200);
            margin-bottom: 2rem;
        }

        .nav-tab {
            padding: 1rem 1.5rem;
            background: transparent;
            border: none;
            border-bottom: 3px solid transparent;
            color: var(--gray-600);
            font-weight: 600;
            font-size: 0.875rem;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
        }

        .nav-tab:hover {
            color: var(--primary);
        }

        .nav-tab.active {
            color: var(--primary);
            border-bottom-color: var(--primary);
        }

        .tab-content {
            display: none;
        }

        .tab-content.active {
            display: block;
            animation: fadeIn 0.3s ease;
        }

        /* Progress Steps */
        .progress-steps {
            background: var(--white);
            border-radius: 16px;
            padding: 1.5rem;
            margin-bottom: 2rem;
            box-shadow: var(--shadow-sm);
        }

        .steps-container {
            display: flex;
            justify-content: space-between;
            position: relative;
        }

        .step {
            display: flex;
            flex-direction: column;
            align-items: center;
            flex: 1;
            position: relative;
        }

        .step-number {
            width: 48px;
            height: 48px;
            border-radius: 50%;
            background: var(--gray-200);
            color: var(--gray-600);
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: 700;
            font-size: 1.125rem;
            margin-bottom: 0.5rem;
            position: relative;
            z-index: 2;
            transition: all 0.3s ease;
        }

        .step.active .step-number {
            background: var(--primary);
            color: var(--white);
            box-shadow: 0 4px 12px rgba(0, 86, 210, 0.3);
        }

        .step.completed .step-number {
            background: var(--success);
            color: var(--white);
        }

        .step-title {
            font-size: 0.875rem;
            font-weight: 600;
            color: var(--gray-600);
            text-align: center;
            transition: all 0.3s ease;
        }

        .step.active .step-title {
            color: var(--primary);
        }

        .step.completed .step-title {
            color: var(--success);
        }

        .step-line {
            position: absolute;
            top: 24px;
            left: 50%;
            width: 100%;
            height: 2px;
            background: var(--gray-200);
            z-index: 1;
        }

        .step:last-child .step-line {
            display: none;
        }

        .step.completed .step-line {
            background: var(--success);
        }

        /* Form Section */
        .form-section {
            background: var(--white);
            border-radius: 16px;
            padding: 2rem;
            margin-bottom: 1.5rem;
            box-shadow: var(--shadow-sm);
            transition: all 0.3s ease;
        }

        .form-section:hover {
            box-shadow: var(--shadow-md);
        }

        .section-header {
            display: flex;
            align-items: center;
            gap: 1rem;
            margin-bottom: 1.5rem;
            padding-bottom: 1rem;
            border-bottom: 2px solid var(--gray-100);
        }

        .section-icon {
            width: 48px;
            height: 48px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 1.25rem;
        }

        .section-icon.blue {
            background: rgba(0, 86, 210, 0.1);
            color: var(--primary);
        }

        .section-icon.green {
            background: rgba(0, 200, 83, 0.1);
            color: var(--success);
        }

        .section-icon.orange {
            background: rgba(255, 149, 0, 0.1);
            color: var(--warning);
        }

        .section-icon.purple {
            background: rgba(124, 58, 237, 0.1);
            color: #7c3aed;
        }

        .section-title {
            font-size: 1.25rem;
            font-weight: 700;
            color: var(--dark);
            margin: 0;
        }

        .section-subtitle {
            font-size: 0.875rem;
            color: var(--gray-600);
            margin: 0.25rem 0 0 0;
        }

        /* Form Controls */
        .form-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 1.5rem;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .form-label {
            font-size: 0.875rem;
            font-weight: 600;
            color: var(--gray-700);
            margin-bottom: 0.5rem;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .form-label .required {
            color: var(--danger);
        }

        .form-control,
        .form-select {
            padding: 0.875rem 1rem;
            border: 2px solid var(--gray-200);
            border-radius: 12px;
            font-size: 0.875rem;
            transition: all 0.2s ease;
            background: var(--gray-100);
        }

        .form-control:focus,
        .form-select:focus {
            outline: none;
            border-color: var(--primary);
            background: var(--white);
            box-shadow: 0 0 0 4px rgba(0, 86, 210, 0.1);
        }

        .form-control::placeholder {
            color: var(--gray-400);
        }

        .form-text {
            font-size: 0.75rem;
            color: var(--gray-500);
            margin-top: 0.25rem;
        }

        .form-control.is-invalid,
        .form-select.is-invalid {
            border-color: var(--danger);
        }

        .form-control.is-valid,
        .form-select.is-valid {
            border-color: var(--success);
        }

        .invalid-feedback {
            font-size: 0.75rem;
            color: var(--danger);
            margin-top: 0.25rem;
            display: none;
        }

        .form-control.is-invalid ~ .invalid-feedback,
        .form-select.is-invalid ~ .invalid-feedback {
            display: block;
        }

        /* Photo Upload */
        .photo-upload-section {
            display: flex;
            align-items: center;
            gap: 2rem;
            padding: 1.5rem;
            background: var(--gray-100);
            border-radius: 12px;
            margin-bottom: 1.5rem;
        }

        .photo-preview {
            width: 150px;
            height: 150px;
            border-radius: 16px;
            background: var(--white);
            border: 3px dashed var(--gray-300);
            display: flex;
            align-items: center;
            justify-content: center;
            overflow: hidden;
            position: relative;
            transition: all 0.3s ease;
        }

        .photo-preview:hover {
            border-color: var(--primary);
            transform: scale(1.02);
        }

        .photo-preview img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }

        .photo-placeholder {
            text-align: center;
            color: var(--gray-500);
        }

        .photo-placeholder i {
            font-size: 3rem;
            margin-bottom: 0.5rem;
        }

        .photo-info h4 {
            font-size: 1rem;
            font-weight: 600;
            color: var(--dark);
            margin-bottom: 0.5rem;
        }

        .photo-info p {
            font-size: 0.875rem;
            color: var(--gray-600);
            margin-bottom: 1rem;
        }

        .btn-upload {
            padding: 0.75rem 1.5rem;
            border: none;
            border-radius: 12px;
            font-weight: 600;
            font-size: 0.875rem;
            cursor: pointer;
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            background: var(--primary);
            color: var(--white);
        }

        .btn-upload:hover {
            background: var(--primary-dark);
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
        }

        /* Button Group */
        .btn-group-toggle .btn {
            padding: 0.75rem 1.5rem;
            border: 2px solid var(--gray-200);
            background: var(--white);
            color: var(--gray-700);
            font-weight: 600;
            font-size: 0.875rem;
            transition: all 0.2s ease;
        }

        .btn-group-toggle .btn:first-child {
            border-radius: 12px 0 0 12px;
        }

        .btn-group-toggle .btn:last-child {
            border-radius: 0 12px 12px 0;
        }

        .btn-group-toggle .btn.active {
            background: var(--primary);
            color: var(--white);
            border-color: var(--primary);
        }

        /* Dependentes Section */
        .dependente-card {
            background: var(--gray-100);
            border-radius: 12px;
            padding: 1.5rem;
            margin-bottom: 1rem;
            position: relative;
            transition: all 0.3s ease;
        }

        .dependente-card:hover {
            background: var(--gray-200);
        }

        .dependente-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            margin-bottom: 1rem;
        }

        .dependente-number {
            font-weight: 700;
            color: var(--primary);
            font-size: 0.875rem;
        }

        .btn-remove-dependente {
            width: 32px;
            height: 32px;
            border: none;
            background: rgba(255, 59, 48, 0.1);
            color: var(--danger);
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.2s ease;
        }

        .btn-remove-dependente:hover {
            background: var(--danger);
            color: var(--white);
        }

        .btn-add-dependente {
            width: 100%;
            padding: 1rem;
            border: 2px dashed var(--gray-300);
            background: transparent;
            border-radius: 12px;
            color: var(--gray-600);
            font-weight: 600;
            font-size: 0.875rem;
            cursor: pointer;
            transition: all 0.2s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 0.5rem;
        }

        .btn-add-dependente:hover {
            border-color: var(--primary);
            color: var(--primary);
            background: var(--primary-light);
        }

        /* Services Section */
        .services-info {
            background: #d1ecf1;
            border: 1px solid #bee5eb;
            border-radius: 12px;
            padding: 1rem;
            margin-bottom: 2rem;
            color: #0c5460;
            font-size: 0.875rem;
        }

        .services-info i {
            margin-right: 0.5rem;
        }

        .service-card {
            background: var(--white);
            border-radius: 16px;
            padding: 2rem;
            margin-bottom: 1.5rem;
            box-shadow: var(--shadow-sm);
            transition: all 0.3s ease;
        }

        .service-card:hover {
            box-shadow: var(--shadow-md);
        }

        .service-header {
            background: var(--primary);
            color: var(--white);
            padding: 1rem 1.5rem;
            border-radius: 12px 12px 0 0;
            margin: -2rem -2rem 1.5rem -2rem;
        }

        .service-header.juridico {
            background: var(--gray-700);
        }

        .service-header h3 {
            margin: 0;
            font-size: 1.125rem;
            font-weight: 700;
        }

        .service-details {
            margin-bottom: 1.5rem;
        }

        .service-details p {
            margin-bottom: 1rem;
            color: var(--gray-700);
        }

        .service-option {
            display: flex;
            align-items: center;
            padding: 0.75rem;
            margin-bottom: 0.5rem;
            background: var(--gray-100);
            border-radius: 8px;
        }

        .service-option strong {
            color: var(--dark);
            margin-right: 0.5rem;
        }

        .valor-base {
            font-size: 1.125rem;
            font-weight: 700;
            color: var(--primary);
            margin-top: 1rem;
        }

        .service-checkbox {
            display: flex;
            align-items: center;
            gap: 0.75rem;
            padding: 1rem;
            background: var(--gray-100);
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.2s ease;
        }

        .service-checkbox:hover {
            background: var(--gray-200);
        }

        .service-checkbox input[type="checkbox"] {
            width: 20px;
            height: 20px;
            cursor: pointer;
        }

        .service-checkbox label {
            margin: 0;
            cursor: pointer;
            font-weight: 600;
            color: var(--gray-700);
        }

        .resumo-valores {
            background: #d4edda;
            border: 1px solid #c3e6cb;
            border-radius: 12px;
            padding: 1.5rem;
            margin-top: 2rem;
        }

        .resumo-valores h3 {
            color: #155724;
            font-size: 1.125rem;
            font-weight: 700;
            margin-bottom: 1rem;
        }

        .resumo-valores .resumo-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 1rem;
            margin-bottom: 1rem;
        }

        .resumo-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .resumo-item strong {
            color: #155724;
        }

        .total-mensal {
            text-align: right;
            font-size: 1.5rem;
            font-weight: 800;
            color: #155724;
            margin-top: 1rem;
            padding-top: 1rem;
            border-top: 2px solid #c3e6cb;
        }

        /* Actions Footer */
        .form-actions {
            background: var(--white);
            border-radius: 16px;
            padding: 2rem;
            box-shadow: var(--shadow-sm);
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
            gap: 1rem;
            position: sticky;
            bottom: 2rem;
            z-index: 50;
        }

        .btn-modern {
            padding: 0.875rem 2rem;
            border: none;
            border-radius: 12px;
            font-weight: 600;
            font-size: 0.875rem;
            cursor: pointer;
            transition: all 0.2s ease;
            display: inline-flex;
            align-items: center;
            gap: 0.5rem;
            text-decoration: none;
        }

        .btn-primary {
            background: var(--primary);
            color: var(--white);
            box-shadow: 0 2px 8px rgba(0, 86, 210, 0.25);
        }

        .btn-primary:hover {
            background: var(--primary-dark);
            transform: translateY(-2px);
            box-shadow: var(--shadow-md);
        }

        .btn-secondary {
            background: var(--gray-100);
            color: var(--gray-700);
        }

        .btn-secondary:hover {
            background: var(--gray-200);
        }

        .btn-outline-danger {
            background: transparent;
            color: var(--danger);
            border: 2px solid var(--danger);
        }

        .btn-outline-danger:hover {
            background: var(--danger);
            color: var(--white);
        }

        /* Loading Overlay */
        .loading-overlay {
            position: fixed;
            top: 0;
            left: 0;
            right: 0;
            bottom: 0;
            background: rgba(255, 255, 255, 0.95);
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            z-index: 9999;
            opacity: 0;
            visibility: hidden;
            transition: all 0.3s ease;
        }

        .loading-overlay.active {
            opacity: 1;
            visibility: visible;
        }

        .loading-spinner {
            width: 50px;
            height: 50px;
            border: 4px solid var(--gray-200);
            border-top-color: var(--primary);
            border-radius: 50%;
            animation: spin 1s linear infinite;
        }

        .loading-text {
            margin-top: 1rem;
            color: var(--gray-600);
            font-weight: 500;
        }

        @keyframes spin {
            to { transform: rotate(360deg); }
        }

        /* CEP Loading */
        .cep-loading {
            position: relative;
        }

        .cep-loading::after {
            content: '';
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            width: 16px;
            height: 16px;
            border: 2px solid var(--gray-300);
            border-top-color: var(--primary);
            border-radius: 50%;
            animation: spin 0.6s linear infinite;
        }

        /* Autocomplete */
        .autocomplete-container {
            position: relative;
        }

        .autocomplete-suggestions {
            position: absolute;
            top: 100%;
            left: 0;
            right: 0;
            background: var(--white);
            border: 2px solid var(--gray-200);
            border-top: none;
            border-radius: 0 0 12px 12px;
            max-height: 200px;
            overflow-y: auto;
            display: none;
            z-index: 100;
            box-shadow: var(--shadow-md);
        }

        .autocomplete-suggestions.show {
            display: block;
        }

        .autocomplete-item {
            padding: 0.75rem 1rem;
            cursor: pointer;
            transition: all 0.2s ease;
            border-bottom: 1px solid var(--gray-100);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .autocomplete-item:last-child {
            border-bottom: none;
        }

        .autocomplete-item:hover,
        .autocomplete-item.active {
            background: var(--primary-light);
            color: var(--primary);
        }

        .autocomplete-item i {
            font-size: 0.875rem;
            color: var(--gray-500);
        }

        .autocomplete-item strong {
            color: var(--primary);
            font-weight: 700;
        }

        .autocomplete-empty {
            padding: 1rem;
            text-align: center;
            color: var(--gray-500);
            font-size: 0.875rem;
        }

        .autocomplete-loading {
            padding: 1rem;
            text-align: center;
            color: var(--gray-600);
        }

        .autocomplete-loading i {
            animation: spin 1s linear infinite;
        }

        /* Tooltips */
        .tooltip-icon {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            width: 18px;
            height: 18px;
            background: var(--gray-200);
            color: var(--gray-600);
            border-radius: 50%;
            font-size: 0.75rem;
            cursor: help;
            margin-left: 0.25rem;
        }

        .tooltip-icon:hover {
            background: var(--primary);
            color: var(--white);
        }

        /* Responsive */
        @media (max-width: 768px) {
            .content-area {
                padding: 1rem;
            }
            
            .form-section {
                padding: 1.5rem;
            }
            
            .form-grid {
                grid-template-columns: 1fr;
            }
            
            .photo-upload-section {
                flex-direction: column;
                text-align: center;
            }
            
            .form-actions {
                position: static;
                flex-direction: column;
            }
            
            .btn-modern {
                width: 100%;
                justify-content: center;
            }
            
            .steps-container {
                overflow-x: auto;
            }
            
            .user-info {
                display: none;
            }

            .nav-tabs-custom {
                overflow-x: auto;
                flex-wrap: nowrap;
            }
        }

        /* Animations */
        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .fade-in {
            animation: fadeIn 0.5s ease forwards;
        }
    </style>
</head>
<body>
    <!-- Loading Overlay -->
    <div class="loading-overlay" id="loadingOverlay">
        <div class="loading-spinner"></div>
        <div class="loading-text">Processando...</div>
    </div>

    <!-- Main Content -->
    <div class="main-wrapper">
        <!-- Header -->
        <header class="main-header">
            <div class="header-left">
                <div class="logo-section">
                    <div style="width: 40px; height: 40px; background: var(--primary); border-radius: 10px; display: flex; align-items: center; justify-content: center; color: white; font-weight: 800;">
                        A
                    </div>
                    <div>
                        <h1 class="logo-text" style="margin-bottom: -2px;">ASSEGO</h1>
                        <p class="system-subtitle">Sistema de Gestão</p>
                    </div>
                </div>
            </div>
            
            <div class="header-right">
                <button class="header-btn" onclick="window.history.back()">
                    <i class="fas fa-arrow-left"></i>
                </button>
                <div class="user-menu" id="userMenu">
                    <div class="user-info">
                        <p class="user-name"><?php echo htmlspecialchars(USUARIO_LOGADO_NOME); ?></p>
                        <p class="user-role">Administrador</p>
                    </div>
                    <div class="user-avatar">
                        <?php echo strtoupper(substr(USUARIO_LOGADO_NOME, 0, 1)); ?>
                    </div>
                    <i class="fas fa-chevron-down ms-2" style="font-size: 0.75rem; color: var(--gray-500);"></i>
                    
                    <!-- Dropdown Menu -->
                    <div class="dropdown-menu-custom" id="userDropdown">
                        <a href="#" class="dropdown-item-custom">
                            <i class="fas fa-user"></i>
                            <span>Meu Perfil</span>
                        </a>
                        <a href="#" class="dropdown-item-custom">
                            <i class="fas fa-cog"></i>
                            <span>Configurações</span>
                        </a>
                        <div class="dropdown-divider-custom"></div>
                        <a href="../php/login/logout.php" class="dropdown-item-custom">
                            <i class="fas fa-sign-out-alt"></i>
                            <span>Sair</span>
                        </a>
                    </div>
                </div>
            </div>
        </header>

        <!-- Content Area -->
        <div class="content-area">
            <!-- Page Header -->
            <div class="page-header">
                <div>
                    <h1 class="page-title">
                        <?php echo $isEdicao ? 'Editar Associado' : 'Novo Associado'; ?>
                    </h1>
                    <p class="page-subtitle">
                        <?php echo $isEdicao ? 'Atualize os dados do associado' : 'Preencha o formulário para cadastrar um novo associado'; ?>
                    </p>
                </div>
                <div class="page-actions">
                    <button type="button" class="btn-modern btn-secondary" onclick="window.history.back()">
                        <i class="fas fa-times"></i>
                        Cancelar
                    </button>
                    <button type="submit" form="formAssociado" class="btn-modern btn-primary">
                        <i class="fas fa-save"></i>
                        <?php echo $isEdicao ? 'Salvar Alterações' : 'Cadastrar Associado'; ?>
                    </button>
                </div>
            </div>

            <!-- Tabs Navigation -->
            <div class="nav-tabs-custom">
                <button class="nav-tab active" onclick="switchTab('informacoes')">Informações</button>
                <button class="nav-tab" onclick="switchTab('servicos')">Serviços</button>
            </div>

            <!-- Form -->
            <form id="formAssociado" method="POST" enctype="multipart/form-data">
                <?php if ($isEdicao): ?>
                    <input type="hidden" name="id" value="<?php echo $associadoId; ?>">
                <?php endif; ?>

                <!-- Tab Informações -->
                <div class="tab-content active" id="tab-informacoes">
                    <!-- Progress Steps -->
                    <div class="progress-steps">
                        <div class="steps-container">
                            <div class="step active" data-step="1">
                                <div class="step-number">1</div>
                                <div class="step-title">Dados Pessoais</div>
                                <div class="step-line"></div>
                            </div>
                            <div class="step" data-step="2">
                                <div class="step-number">2</div>
                                <div class="step-title">Dados Militares</div>
                                <div class="step-line"></div>
                            </div>
                            <div class="step" data-step="3">
                                <div class="step-number">3</div>
                                <div class="step-title">Endereço</div>
                                <div class="step-line"></div>
                            </div>
                            <div class="step" data-step="4">
                                <div class="step-number">4</div>
                                <div class="step-title">Financeiro</div>
                                <div class="step-line"></div>
                            </div>
                            <div class="step" data-step="5">
                                <div class="step-number">5</div>
                                <div class="step-title">Dependentes</div>
                            </div>
                        </div>
                    </div>

                    <!-- Dados Pessoais -->
                    <div class="form-section fade-in">
                        <div class="section-header">
                            <div class="section-icon blue">
                                <i class="fas fa-user"></i>
                            </div>
                            <div>
                                <h2 class="section-title">Dados Pessoais</h2>
                                <p class="section-subtitle">Informações básicas do associado</p>
                            </div>
                        </div>

                        <!-- Photo Upload -->
                        <div class="photo-upload-section">
                            <div class="photo-preview" id="photoPreview">
                                <?php if ($isEdicao && $dadosAssociado['foto']): ?>
                                    <img src="<?php echo htmlspecialchars($dadosAssociado['foto']); ?>" alt="Foto do associado">
                                <?php else: ?>
                                    <div class="photo-placeholder">
                                        <i class="fas fa-camera"></i>
                                        <p>Sem foto</p>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="photo-info">
                                <h4>Foto do Associado</h4>
                                <p>Faça upload de uma foto em formato JPG ou PNG. Tamanho máximo: 5MB</p>
                                <input type="file" id="inputFoto" name="foto" accept="image/*" style="display: none;">
                                <button type="button" class="btn-upload" onclick="document.getElementById('inputFoto').click()">
                                    <i class="fas fa-upload"></i>
                                    Escolher Foto
                                </button>
                            </div>
                        </div>

                        <div class="form-grid">
                            <div class="form-group">
                                <label class="form-label">
                                    Nome Completo <span class="required">*</span>
                                </label>
                                <input type="text" class="form-control" id="nome" name="nome" 
                                       value="<?php echo $isEdicao ? htmlspecialchars($dadosAssociado['nome']) : ''; ?>" 
                                       required>
                                <div class="invalid-feedback">Por favor, informe o nome completo</div>
                            </div>

                            <div class="form-group">
                                <label class="form-label">
                                    CPF <span class="required">*</span>
                                </label>
                                <input type="text" class="form-control" id="cpf" name="cpf" 
                                       value="<?php echo $isEdicao ? htmlspecialchars($dadosAssociado['cpf']) : ''; ?>" 
                                       placeholder="000.000.000-00" required>
                                <div class="invalid-feedback">CPF inválido</div>
                            </div>

                            <div class="form-group">
                                <label class="form-label">
                                    RG <span class="required">*</span>
                                </label>
                                <input type="text" class="form-control" id="rg" name="rg" 
                                       value="<?php echo $isEdicao ? htmlspecialchars($dadosAssociado['rg']) : ''; ?>" 
                                       required>
                                <div class="invalid-feedback">Por favor, informe o RG</div>
                            </div>

                            <div class="form-group">
                                <label class="form-label">
                                    Data de Nascimento <span class="required">*</span>
                                </label>
                                <input type="date" class="form-control" id="nasc" name="nasc" 
                                       value="<?php echo $isEdicao ? $dadosAssociado['nasc'] : ''; ?>" 
                                       required>
                                <div class="invalid-feedback">Por favor, informe a data de nascimento</div>
                            </div>

                            <div class="form-group">
                                <label class="form-label">
                                    Sexo <span class="required">*</span>
                                </label>
                                <div class="btn-group btn-group-toggle w-100" role="group">
                                    <input type="radio" class="btn-check" name="sexo" id="sexoM" value="M" 
                                           <?php echo ($isEdicao && $dadosAssociado['sexo'] == 'M') ? 'checked' : ''; ?> required>
                                    <label class="btn" for="sexoM">Masculino</label>
                                    
                                    <input type="radio" class="btn-check" name="sexo" id="sexoF" value="F" 
                                           <?php echo ($isEdicao && $dadosAssociado['sexo'] == 'F') ? 'checked' : ''; ?> required>
                                    <label class="btn" for="sexoF">Feminino</label>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="form-label">Estado Civil</label>
                                <select class="form-select" id="estadoCivil" name="estadoCivil">
                                    <option value="">Selecione...</option>
                                    <option value="Solteiro" <?php echo ($isEdicao && (isSelected($dadosAssociado['estadoCivil'], 'Solteiro') || isSelected($dadosAssociado['estadoCivil'], 'Solteiro(a)'))) ? 'selected' : ''; ?>>Solteiro(a)</option>
                                    <option value="Casado" <?php echo ($isEdicao && (isSelected($dadosAssociado['estadoCivil'], 'Casado') || isSelected($dadosAssociado['estadoCivil'], 'Casado(a)'))) ? 'selected' : ''; ?>>Casado(a)</option>
                                    <option value="Divorciado" <?php echo ($isEdicao && (isSelected($dadosAssociado['estadoCivil'], 'Divorciado') || isSelected($dadosAssociado['estadoCivil'], 'Divorciado(a)') || isSelected($dadosAssociado['estadoCivil'], 'Separado(a)'))) ? 'selected' : ''; ?>>Divorciado(a)</option>
                                    <option value="Viúvo" <?php echo ($isEdicao && (isSelected($dadosAssociado['estadoCivil'], 'Viúvo') || isSelected($dadosAssociado['estadoCivil'], 'Viuvo') || isSelected($dadosAssociado['estadoCivil'], 'Viuvo(a)') || isSelected($dadosAssociado['estadoCivil'], 'Viúvo(a)'))) ? 'selected' : ''; ?>>Viúvo(a)</option>
                                    <option value="União Estável" <?php echo ($isEdicao && (isSelected($dadosAssociado['estadoCivil'], 'União Estável') || isSelected($dadosAssociado['estadoCivil'], 'Uniao Estavel') || isSelected($dadosAssociado['estadoCivil'], 'Uniao estavel'))) ? 'selected' : ''; ?>>União Estável</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label class="form-label">Escolaridade</label>
                                <select class="form-select" id="escolaridade" name="escolaridade">
                                    <option value="">Selecione...</option>
                                    <option value="Fundamental Incompleto" <?php echo ($isEdicao && isSelected($dadosAssociado['escolaridade'], 'Fundamental Incompleto')) ? 'selected' : ''; ?>>Fundamental Incompleto</option>
                                    <option value="Fundamental Completo" <?php echo ($isEdicao && isSelected($dadosAssociado['escolaridade'], 'Fundamental Completo')) ? 'selected' : ''; ?>>Fundamental Completo</option>
                                    <option value="Médio Incompleto" <?php echo ($isEdicao && (isSelected($dadosAssociado['escolaridade'], 'Médio Incompleto') || isSelected($dadosAssociado['escolaridade'], 'Medio Incompleto'))) ? 'selected' : ''; ?>>Médio Incompleto</option>
                                    <option value="Médio Completo" <?php echo ($isEdicao && (isSelected($dadosAssociado['escolaridade'], 'Médio Completo') || isSelected($dadosAssociado['escolaridade'], 'Medio Completo') || isSelected($dadosAssociado['escolaridade'], 'Ensino Medio') || isSelected($dadosAssociado['escolaridade'], 'Ensino Médio'))) ? 'selected' : ''; ?>>Médio Completo</option>
                                    <option value="Superior Incompleto" <?php echo ($isEdicao && isSelected($dadosAssociado['escolaridade'], 'Superior Incompleto')) ? 'selected' : ''; ?>>Superior Incompleto</option>
                                    <option value="Superior Completo" <?php echo ($isEdicao && isSelected($dadosAssociado['escolaridade'], 'Superior Completo')) ? 'selected' : ''; ?>>Superior Completo</option>
                                    <option value="Pós-Graduação" <?php echo ($isEdicao && (isSelected($dadosAssociado['escolaridade'], 'Pós-Graduação') || isSelected($dadosAssociado['escolaridade'], 'Pos-Graduacao'))) ? 'selected' : ''; ?>>Pós-Graduação</option>
                                    <option value="Mestrado" <?php echo ($isEdicao && (isSelected($dadosAssociado['escolaridade'], 'Mestrado') || isSelected($dadosAssociado['escolaridade'], 'Mestre(a)'))) ? 'selected' : ''; ?>>Mestrado</option>
                                    <option value="Doutorado" <?php echo ($isEdicao && isSelected($dadosAssociado['escolaridade'], 'Doutorado')) ? 'selected' : ''; ?>>Doutorado</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label class="form-label">
                                    Telefone <span class="required">*</span>
                                </label>
                                <input type="text" class="form-control" id="telefone" name="telefone" 
                                       value="<?php echo $isEdicao ? htmlspecialchars($dadosAssociado['telefone']) : ''; ?>" 
                                       placeholder="(00) 00000-0000" required>
                                <div class="invalid-feedback">Por favor, informe o telefone</div>
                            </div>

                            <div class="form-group">
                                <label class="form-label">E-mail</label>
                                <input type="email" class="form-control" id="email" name="email" 
                                       value="<?php echo $isEdicao ? htmlspecialchars($dadosAssociado['email']) : ''; ?>" 
                                       placeholder="exemplo@email.com">
                                <div class="invalid-feedback">E-mail inválido</div>
                            </div>

                            <div class="form-group">
                                <label class="form-label">
                                    Situação <span class="required">*</span>
                                </label>
                                <select class="form-select" id="situacao" name="situacao" required>
                                    <option value="">Selecione...</option>
                                    <option value="Filiado" <?php echo ($isEdicao && isSelected($dadosAssociado['situacao'], 'Filiado')) ? 'selected' : ''; ?>>Filiado</option>
                                    <option value="Desfiliado" <?php echo ($isEdicao && isSelected($dadosAssociado['situacao'], 'Desfiliado')) ? 'selected' : ''; ?>>Desfiliado</option>
                                    <option value="Falecido" <?php echo ($isEdicao && isSelected($dadosAssociado['situacao'], 'Falecido')) ? 'selected' : ''; ?>>Falecido</option>
                                    <option value="Afastado" <?php echo ($isEdicao && isSelected($dadosAssociado['situacao'], 'Afastado')) ? 'selected' : ''; ?>>Afastado</option>
                                    <option value="Suspenso" <?php echo ($isEdicao && isSelected($dadosAssociado['situacao'], 'Suspenso')) ? 'selected' : ''; ?>>Suspenso</option>
                                    <option value="Virtual" <?php echo ($isEdicao && isSelected($dadosAssociado['situacao'], 'Virtual')) ? 'selected' : ''; ?>>Virtual</option>
                                    <option value="Expulso" <?php echo ($isEdicao && isSelected($dadosAssociado['situacao'], 'Expulso')) ? 'selected' : ''; ?>>Expulso</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label class="form-label">
                                    Indicado por
                                    <i class="fas fa-question-circle tooltip-icon" title="Nome da pessoa que indicou o associado"></i>
                                </label>
                                <div class="autocomplete-container">
                                    <input type="text" class="form-control" id="indicacao" name="indicacao" 
                                           value="<?php echo $isEdicao ? htmlspecialchars($dadosAssociado['indicacao']) : ''; ?>" 
                                           placeholder="Digite para buscar ou adicionar novo indicador"
                                           autocomplete="off">
                                    <div class="autocomplete-suggestions" id="indicacaoSuggestions"></div>
                                </div>
                                <span class="form-text">Comece a digitar para ver sugestões de indicadores já cadastrados</span>
                            </div>
                        </div>
                    </div>

                    <!-- Dados Militares -->
                    <div class="form-section fade-in">
                        <div class="section-header">
                            <div class="section-icon green">
                                <i class="fas fa-shield-alt"></i>
                            </div>
                            <div>
                                <h2 class="section-title">Dados Militares</h2>
                                <p class="section-subtitle">Informações sobre a carreira militar</p>
                            </div>
                        </div>

                        <div class="form-grid">
                            <div class="form-group">
                                <label class="form-label">Corporação <span class="required">*</span></label>
                                <select class="form-select" id="corporacao" name="corporacao" required>
                                    <option value="">Selecione...</option>
                                    <option value="Polícia Militar" <?php echo ($isEdicao && (isSelected($dadosAssociado['corporacao'], 'Polícia Militar') || isSelected($dadosAssociado['corporacao'], 'Policia Militar'))) ? 'selected' : ''; ?>>Polícia Militar</option>
                                    <option value="Bombeiro Militar" <?php echo ($isEdicao && isSelected($dadosAssociado['corporacao'], 'Bombeiro Militar')) ? 'selected' : ''; ?>>Bombeiro Militar</option>
                                    <option value="Agregado" <?php echo ($isEdicao && (isSelected($dadosAssociado['corporacao'], 'Agregado') || isSelected($dadosAssociado['corporacao'], 'Agregados'))) ? 'selected' : ''; ?>>Agregado</option>
                                    <option value="Civil" <?php echo ($isEdicao && (isSelected($dadosAssociado['corporacao'], 'Civil') || isSelected($dadosAssociado['corporacao'], 'Outros') || isSelected($dadosAssociado['corporacao'], 'Pensionista'))) ? 'selected' : ''; ?>>Civil</option>
                                    <option value="Exército" <?php echo ($isEdicao && (isSelected($dadosAssociado['corporacao'], 'Exército') || isSelected($dadosAssociado['corporacao'], 'Exercito'))) ? 'selected' : ''; ?>>Exército</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label class="form-label">Patente</label>
                                <input type="text" class="form-control" id="patente" name="patente" 
                                       value="<?php echo $isEdicao ? htmlspecialchars($dadosAssociado['patente']) : ''; ?>" 
                                       placeholder="Ex: Coronel, Major, Capitão...">
                            </div>

                            <div class="form-group">
                                <label class="form-label">Situação Funcional <span class="required">*</span></label>
                                <select class="form-select" id="categoria" name="categoria" required>
                                    <option value="">Selecione...</option>
                                    <option value="Ativa" <?php echo ($isEdicao && isSelected($dadosAssociado['categoria'], 'Ativa')) ? 'selected' : ''; ?>>Ativa</option>
                                    <option value="Reserva" <?php echo ($isEdicao && isSelected($dadosAssociado['categoria'], 'Reserva')) ? 'selected' : ''; ?>>Reserva</option>
                                    <option value="Pensionista" <?php echo ($isEdicao && isSelected($dadosAssociado['categoria'], 'Pensionista')) ? 'selected' : ''; ?>>Pensionista</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label class="form-label">Unidade</label>
                                <input type="text" class="form-control" id="unidade" name="unidade" 
                                       value="<?php echo $isEdicao ? htmlspecialchars($dadosAssociado['unidade']) : ''; ?>" 
                                       placeholder="Unidade de serviço">
                            </div>

                            <div class="form-group">
                                <label class="form-label">Lotação</label>
                                <input type="text" class="form-control" id="lotacao" name="lotacao" 
                                       value="<?php echo $isEdicao ? htmlspecialchars($dadosAssociado['lotacao']) : ''; ?>" 
                                       placeholder="Local de lotação">
                            </div>

                            <div class="form-group">
                                <label class="form-label">Data de Filiação</label>
                                <input type="date" class="form-control" id="dataFiliacao" name="dataFiliacao" 
                                       value="<?php echo $isEdicao ? $dadosAssociado['dataFiliacao'] : ''; ?>">
                            </div>

                            <div class="form-group">
                                <label class="form-label">Data de Desfiliação</label>
                                <input type="date" class="form-control" id="dataDesfiliacao" name="dataDesfiliacao" 
                                       value="<?php echo $isEdicao ? $dadosAssociado['dataDesfiliacao'] : ''; ?>">
                            </div>
                        </div>
                    </div>

                    <!-- Endereço -->
                    <div class="form-section fade-in">
                        <div class="section-header">
                            <div class="section-icon orange">
                                <i class="fas fa-map-marker-alt"></i>
                            </div>
                            <div>
                                <h2 class="section-title">Endereço</h2>
                                <p class="section-subtitle">Dados de localização do associado</p>
                            </div>
                        </div>

                        <div class="form-grid">
                            <div class="form-group">
                                <label class="form-label">
                                    CEP
                                    <i class="fas fa-search tooltip-icon" style="cursor: pointer;" onclick="buscarCEP(true)" title="Buscar endereço pelo CEP"></i>
                                </label>
                                <input type="text" class="form-control" id="cep" name="cep" 
                                       value="<?php echo $isEdicao ? htmlspecialchars($dadosAssociado['cep']) : ''; ?>" 
                                       placeholder="00000-000">
                                <span class="form-text">Digite o CEP e o endereço será preenchido automaticamente</span>
                            </div>

                            <div class="form-group" style="grid-column: span 2;">
                                <label class="form-label">Endereço</label>
                                <input type="text" class="form-control" id="endereco" name="endereco" 
                                       value="<?php echo $isEdicao ? htmlspecialchars($dadosAssociado['endereco']) : ''; ?>" 
                                       placeholder="Rua, Avenida...">
                            </div>

                            <div class="form-group">
                                <label class="form-label">Número</label>
                                <input type="text" class="form-control" id="numero" name="numero" 
                                       value="<?php echo $isEdicao ? htmlspecialchars($dadosAssociado['numero']) : ''; ?>" 
                                       placeholder="Nº">
                            </div>

                            <div class="form-group">
                                <label class="form-label">Complemento</label>
                                <input type="text" class="form-control" id="complemento" name="complemento" 
                                       value="<?php echo $isEdicao ? htmlspecialchars($dadosAssociado['complemento']) : ''; ?>" 
                                       placeholder="Apto, Bloco...">
                            </div>

                            <div class="form-group">
                                <label class="form-label">Bairro</label>
                                <input type="text" class="form-control" id="bairro" name="bairro" 
                                       value="<?php echo $isEdicao ? htmlspecialchars($dadosAssociado['bairro']) : ''; ?>" 
                                       placeholder="Bairro">
                            </div>

                            <div class="form-group">
                                <label class="form-label">Cidade</label>
                                <input type="text" class="form-control" id="cidade" name="cidade" 
                                       value="<?php echo $isEdicao ? htmlspecialchars($dadosAssociado['cidade']) : ''; ?>" 
                                       placeholder="Cidade">
                            </div>
                        </div>
                    </div>

                    <!-- Dados Financeiros -->
                    <div class="form-section fade-in">
                        <div class="section-header">
                            <div class="section-icon purple">
                                <i class="fas fa-dollar-sign"></i>
                            </div>
                            <div>
                                <h2 class="section-title">Dados Financeiros</h2>
                                <p class="section-subtitle">Informações para cobrança e pagamentos</p>
                            </div>
                        </div>

                        <div class="form-grid">
                            <div class="form-group">
                                <label class="form-label">Tipo do Associado <span class="required">*</span></label>
                                <select class="form-select" id="tipoAssociado" name="tipoAssociado" required onchange="calcularServicos()">
                                    <option value="">Selecione...</option>
                                    <option value="Contribuinte">Contribuinte</option>
                                    <option value="Agregado">Agregado</option>
                                    <option value="Benemerito">Benemérito</option>
                                    <option value="Remido 50%">Remido 50%</option>
                                    <option value="Remido">Remido</option>
                                </select>
                                
                                <?php if ($isEdicao && isset($dadosAssociado['tipoAssociado']) && !empty($dadosAssociado['tipoAssociado'])): ?>
                                <script>
                                // Solução definitiva - força a seleção após o carregamento
                                (function() {
                                    const tipoValue = <?php echo json_encode($dadosAssociado['tipoAssociado']); ?>;
                                    
                                    function selecionarTipo() {
                                        const select = document.getElementById('tipoAssociado');
                                        if (!select) return;
                                        
                                        console.log('Selecionando tipo:', tipoValue);
                                        
                                        // Remove espaços extras
                                        const valorLimpo = tipoValue.trim();
                                        
                                        // Procura a opção correta
                                        for (let i = 0; i < select.options.length; i++) {
                                            if (select.options[i].value === valorLimpo) {
                                                select.selectedIndex = i;
                                                console.log('✅ Tipo selecionado:', valorLimpo);
                                                
                                                // Dispara o cálculo após um pequeno delay
                                                setTimeout(function() {
                                                    if (typeof calcularServicos === 'function') {
                                                        calcularServicos();
                                                    }
                                                }, 100);
                                                
                                                return;
                                            }
                                        }
                                        
                                        console.error('❌ Não foi possível selecionar o tipo:', valorLimpo);
                                    }
                                    
                                    // Executa quando o DOM estiver pronto
                                    if (document.readyState === 'loading') {
                                        document.addEventListener('DOMContentLoaded', selecionarTipo);
                                    } else {
                                        // Se já carregou, executa imediatamente
                                        setTimeout(selecionarTipo, 0);
                                    }
                                })();
                                </script>
                                <?php endif; ?>
                            </div>

                            <div class="form-group">
                                <label class="form-label">Situação Financeira <span class="required">*</span></label>
                                <select class="form-select" id="situacaoFinanceira" name="situacaoFinanceira" required>
                                    <option value="">Selecione...</option>
                                    <option value="Adiplente" <?php echo ($isEdicao && (isSelected($dadosAssociado['situacaoFinanceira'], 'Adiplente') || isSelected($dadosAssociado['situacaoFinanceira'], 'Adimplente'))) ? 'selected' : ''; ?>>Adimplente</option>
                                    <option value="Inadiplente" <?php echo ($isEdicao && (isSelected($dadosAssociado['situacaoFinanceira'], 'Inadiplente') || isSelected($dadosAssociado['situacaoFinanceira'], 'Inadimplente'))) ? 'selected' : ''; ?>>Inadimplente</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label class="form-label">Vínculo Servidor</label>
                                <input type="text" class="form-control" id="vinculoServidor" name="vinculoServidor" 
                                       value="<?php echo $isEdicao ? htmlspecialchars($dadosAssociado['vinculoServidor']) : ''; ?>" 
                                       placeholder="Tipo de vínculo">
                            </div>

                            <div class="form-group">
                                <label class="form-label">Local de Débito</label>
                                <select class="form-select" id="localDebito" name="localDebito">
                                    <option value="">Selecione...</option>
                                    <option value="Folha de Pagamento" <?php echo ($isEdicao && isSelected($dadosAssociado['localDebito'], 'Folha de Pagamento')) ? 'selected' : ''; ?>>Folha de Pagamento</option>
                                    <option value="Débito em Conta" <?php echo ($isEdicao && isSelected($dadosAssociado['localDebito'], 'Débito em Conta')) ? 'selected' : ''; ?>>Débito em Conta</option>
                                    <option value="Boleto" <?php echo ($isEdicao && isSelected($dadosAssociado['localDebito'], 'Boleto')) ? 'selected' : ''; ?>>Boleto</option>
                                    <option value="PIX" <?php echo ($isEdicao && isSelected($dadosAssociado['localDebito'], 'PIX')) ? 'selected' : ''; ?>>PIX</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label class="form-label">Agência</label>
                                <input type="text" class="form-control" id="agencia" name="agencia" 
                                       value="<?php echo $isEdicao ? htmlspecialchars($dadosAssociado['agencia']) : ''; ?>" 
                                       placeholder="0000">
                            </div>

                            <div class="form-group">
                                <label class="form-label">Operação</label>
                                <input type="text" class="form-control" id="operacao" name="operacao" 
                                       value="<?php echo $isEdicao ? htmlspecialchars($dadosAssociado['operacao']) : ''; ?>" 
                                       placeholder="000">
                            </div>

                            <div class="form-group">
                                <label class="form-label">Conta Corrente</label>
                                <input type="text" class="form-control" id="contaCorrente" name="contaCorrente" 
                                       value="<?php echo $isEdicao ? htmlspecialchars($dadosAssociado['contaCorrente']) : ''; ?>" 
                                       placeholder="00000-0">
                            </div>
                        </div>
                    </div>

                    <!-- Dependentes -->
                    <div class="form-section fade-in">
                        <div class="section-header">
                            <div class="section-icon blue">
                                <i class="fas fa-users"></i>
                            </div>
                            <div>
                                <h2 class="section-title">Dependentes</h2>
                                <p class="section-subtitle">Adicione os dependentes do associado</p>
                            </div>
                        </div>

                        <div id="dependentesContainer">
                            <?php if ($isEdicao && !empty($dependentes)): ?>
                                <?php foreach ($dependentes as $index => $dependente): ?>
                                    <div class="dependente-card" data-index="<?php echo $index; ?>">
                                        <div class="dependente-header">
                                            <span class="dependente-number">Dependente #<?php echo $index + 1; ?></span>
                                            <button type="button" class="btn-remove-dependente" onclick="removerDependente(this)">
                                                <i class="fas fa-trash"></i>
                                            </button>
                                        </div>
                                        <div class="form-grid">
                                            <div class="form-group">
                                                <label class="form-label">Nome Completo</label>
                                                <input type="text" class="form-control" name="dependentes[<?php echo $index; ?>][nome]" 
                                                       value="<?php echo htmlspecialchars($dependente['nome']); ?>" required>
                                            </div>
                                            <div class="form-group">
                                                <label class="form-label">Data de Nascimento</label>
                                                <input type="date" class="form-control" name="dependentes[<?php echo $index; ?>][data_nascimento]" 
                                                       value="<?php echo $dependente['data_nascimento']; ?>" required>
                                            </div>
                                            <div class="form-group">
                                                <label class="form-label">Parentesco</label>
                                                <select class="form-select" name="dependentes[<?php echo $index; ?>][parentesco]" required>
                                                    <option value="">Selecione...</option>
                                                    <option value="Cônjuge" <?php echo ($dependente['parentesco'] == 'Cônjuge') ? 'selected' : ''; ?>>Cônjuge</option>
                                                    <option value="Filho(a)" <?php echo ($dependente['parentesco'] == 'Filho(a)') ? 'selected' : ''; ?>>Filho(a)</option>
                                                    <option value="Pai" <?php echo ($dependente['parentesco'] == 'Pai') ? 'selected' : ''; ?>>Pai</option>
                                                    <option value="Mãe" <?php echo ($dependente['parentesco'] == 'Mãe') ? 'selected' : ''; ?>>Mãe</option>
                                                    <option value="Avô/Avó" <?php echo ($dependente['parentesco'] == 'Avô/Avó') ? 'selected' : ''; ?>>Avô/Avó</option>
                                                    <option value="Outro" <?php echo ($dependente['parentesco'] == 'Outro') ? 'selected' : ''; ?>>Outro</option>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label class="form-label">Sexo</label>
                                                <select class="form-select" name="dependentes[<?php echo $index; ?>][sexo]" required>
                                                    <option value="">Selecione...</option>
                                                    <option value="Masculino" <?php echo ($dependente['sexo'] == 'Masculino') ? 'selected' : ''; ?>>Masculino</option>
                                                    <option value="Feminino" <?php echo ($dependente['sexo'] == 'Feminino') ? 'selected' : ''; ?>>Feminino</option>
                                                </select>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </div>

                        <button type="button" class="btn-add-dependente" onclick="adicionarDependente()">
                            <i class="fas fa-plus"></i>
                            Adicionar Dependente
                        </button>
                    </div>
                </div>

                <!-- Tab Serviços -->
                <div class="tab-content" id="tab-servicos">
                    <div class="services-info">
                        <i class="fas fa-info-circle"></i>
                        Os serviços e valores serão calculados automaticamente com base no tipo do associado. O serviço Social é obrigatório (com descontos aplicáveis conforme a categoria). O serviço Jurídico é opcional.
                    </div>

                    <div class="row">
                        <!-- Serviço Social -->
                        <div class="col-md-6">
                            <div class="service-card">
                                <div class="service-header">
                                    <h3>Serviço Social</h3>
                                </div>
                                <div class="service-details">
                                    <p>O serviço social é obrigatório e seu valor é calculado de acordo com o tipo do associado:</p>
                                    
                                    <div class="service-option">
                                        <strong>Contribuinte/Soldado 1ª Classe:</strong> 100% do valor
                                    </div>
                                    <div class="service-option">
                                        <strong>Soldado 2ª Classe/Aluno/Agregado:</strong> 50% do valor
                                    </div>
                                    <div class="service-option">
                                        <strong>Remido/Benemerito:</strong> Isento
                                    </div>
                                    <div class="service-option">
                                        <strong>Remido 50%:</strong> 50% do valor
                                    </div>
                                    
                                    <div class="valor-base">
                                        Valor Base: R$ 173,10
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Serviço Jurídico -->
                        <div class="col-md-6">
                            <div class="service-card">
                                <div class="service-header juridico">
                                    <h3>Serviço Jurídico</h3>
                                </div>
                                <div class="service-details">
                                    <p>O serviço jurídico é opcional e pode ser aderido por qualquer associado:</p>
                                    
                                    <div class="service-option">
                                        <strong>Valor fixo para todas as categorias</strong>
                                    </div>
                                    <div class="service-option">
                                        <strong>Disponível mesmo para associados Remidos</strong>
                                    </div>
                                    <div class="service-option">
                                        <strong>Para Soldado 2ª Classe, o serviço se mantém ao ser promovido</strong>
                                    </div>
                                    
                                    <div class="valor-base">
                                        Valor Base: R$ 43,28
                                    </div>
                                    
                                    <div class="service-checkbox">
                                        <input type="checkbox" id="servicoJuridico" name="servicos[juridico]" 
                                               <?php echo ($isEdicao && in_array(2, array_column($servicosAssociado, 'servico_id'))) ? 'checked' : ''; ?>
                                               onchange="calcularServicos()">
                                        <label for="servicoJuridico">Optante pelo serviço jurídico</label>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- Resumo de Valores -->
                    <div class="resumo-valores">
                        <h3>Resumo de Valores</h3>
                        <div class="resumo-grid">
                            <div class="resumo-item">
                                <strong>Tipo do Associado:</strong>
                                <span id="resumoTipo">-</span>
                            </div>
                            <div class="resumo-item">
                                <strong>Valor Social:</strong>
                                <span id="resumoSocial">R$ 0,00</span>
                            </div>
                            <div class="resumo-item">
                                <strong>Valor Jurídico:</strong>
                                <span id="resumoJuridico">R$ 0,00</span>
                            </div>
                        </div>
                        <div class="total-mensal" id="totalMensal">
                            Total Mensal: R$ 0,00
                        </div>
                    </div>
                </div>

                <!-- Actions Footer -->
                <div class="form-actions">
                    <div>
                        <button type="button" class="btn-modern btn-outline-danger" onclick="confirmarCancelamento()">
                            <i class="fas fa-times"></i>
                            Cancelar
                        </button>
                    </div>
                    <div>
                        <button type="button" class="btn-modern btn-secondary" onclick="salvarRascunho()">
                            <i class="fas fa-save"></i>
                            Salvar Rascunho
                        </button>
                        <button type="submit" class="btn-modern btn-primary">
                            <i class="fas fa-check"></i>
                            <?php echo $isEdicao ? 'Salvar Alterações' : 'Cadastrar Associado'; ?>
                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Scripts -->
    <script>
    // Configuração inicial
    console.log('=== INICIANDO FORMULÁRIO DE CADASTRO ===');

    // Variáveis globais
    let dependenteIndex = <?php echo $isEdicao && !empty($dependentes) ? count($dependentes) : 0; ?>;
    const VALOR_SERVICO_SOCIAL = 173.10;
    const VALOR_SERVICO_JURIDICO = 43.28;
    let cepTimeout = null; // Para debounce da busca de CEP
    let indicacaoTimeout = null; // Para debounce do autocomplete
    let selectedSuggestionIndex = -1; // Para navegação com teclado

    // User Dropdown Menu
    document.addEventListener('DOMContentLoaded', function() {
        const userMenu = document.getElementById('userMenu');
        const userDropdown = document.getElementById('userDropdown');

        if (userMenu && userDropdown) {
            userMenu.addEventListener('click', function(e) {
                e.stopPropagation();
                userDropdown.classList.toggle('show');
            });

            // Fecha dropdown ao clicar fora
            document.addEventListener('click', function() {
                userDropdown.classList.remove('show');
            });
        }

        // Inicializa máscaras
        initMasks();
        
        // Inicializa validação do formulário
        initFormValidation();
        
        // Calcula serviços se for edição
        if (<?php echo $isEdicao ? 'true' : 'false'; ?>) {
            // Aguarda um momento para garantir que o DOM está pronto
            setTimeout(function() {
                calcularServicos();
            }, 500);
        }
            
            // Debug - Mostra os valores carregados do banco
            console.log('=== MODO EDIÇÃO ===');
            console.log('ID:', <?php echo $associadoId ?? 'null'; ?>);
            console.log('Tipo Associado:', <?php echo json_encode($dadosAssociado['tipoAssociado'] ?? null); ?>);
            console.log('==================');
            
            // Verifica valores dos selects
            setTimeout(() => {
                console.log('=== VALORES DOS SELECTS ===');
                console.log('Tipo Associado:', document.getElementById('tipoAssociado').value || 'Não selecionado');
                console.log('==========================');
            }, 500);
        }
    });

    // Loading functions
    function showLoading() {
        const overlay = document.getElementById('loadingOverlay');
        if (overlay) {
            overlay.classList.add('active');
        }
    }

    function hideLoading() {
        const overlay = document.getElementById('loadingOverlay');
        if (overlay) {
            overlay.classList.remove('active');
        }
    }

    // Switch Tabs
    function switchTab(tabName) {
        // Remove active de todas as tabs
        document.querySelectorAll('.nav-tab').forEach(tab => {
            tab.classList.remove('active');
        });
        
        // Remove active de todos os conteúdos
        document.querySelectorAll('.tab-content').forEach(content => {
            content.classList.remove('active');
        });
        
        // Ativa a tab selecionada
        event.target.classList.add('active');
        
        // Ativa o conteúdo correspondente
        document.getElementById(`tab-${tabName}`).classList.add('active');
    }

    // Inicializa máscaras dos campos
    function initMasks() {
        $('#cpf').mask('000.000.000-00');
        $('#telefone').mask('(00) 00000-0000');
        $('#cep').mask('00000-000');
        $('#agencia').mask('0000');
        $('#operacao').mask('000');
        $('#contaCorrente').mask('00000-0');
    }

    // Preview da foto
    document.getElementById('inputFoto').addEventListener('change', function(e) {
        const file = e.target.files[0];
        if (file) {
            // Valida tamanho
            if (file.size > 5 * 1024 * 1024) {
                Swal.fire('Erro', 'A foto deve ter no máximo 5MB', 'error');
                e.target.value = '';
                return;
            }

            // Valida tipo
            if (!file.type.match('image.*')) {
                Swal.fire('Erro', 'Por favor, selecione apenas imagens', 'error');
                e.target.value = '';
                return;
            }

            // Preview
            const reader = new FileReader();
            reader.onload = function(e) {
                document.getElementById('photoPreview').innerHTML = 
                    `<img src="${e.target.result}" alt="Foto do associado">`;
            }
            reader.readAsDataURL(file);
        }
    });

    // Busca CEP - API ViaCEP melhorada
    function buscarCEP(mostrarAvisos = true) {
        const cepInput = document.getElementById('cep');
        const cep = cepInput.value.replace(/\D/g, '');
        
        if (cep.length !== 8) {
            if (mostrarAvisos) {
                Swal.fire({
                    title: 'Aviso',
                    text: 'Por favor, informe um CEP válido com 8 dígitos',
                    icon: 'warning',
                    confirmButtonText: 'OK'
                });
            }
            return;
        }

        // Adiciona loading visual no campo
        cepInput.classList.add('cep-loading');
        cepInput.disabled = true;

        // Limpa os campos antes da busca
        document.getElementById('endereco').value = '';
        document.getElementById('bairro').value = '';
        document.getElementById('cidade').value = '';

        fetch(`https://viacep.com.br/ws/${cep}/json/`)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Erro na requisição');
                }
                return response.json();
            })
            .then(data => {
                // Remove loading
                cepInput.classList.remove('cep-loading');
                cepInput.disabled = false;
                
                if (data.erro) {
                    Swal.fire({
                        title: 'CEP não encontrado',
                        text: 'O CEP informado não foi localizado. Verifique e tente novamente.',
                        icon: 'error',
                        confirmButtonText: 'OK'
                    });
                    return;
                }

                // Preenche os campos com animação
                const campos = {
                    'endereco': data.logradouro || '',
                    'bairro': data.bairro || '',
                    'cidade': data.localidade || ''
                };

                for (let campo in campos) {
                    const element = document.getElementById(campo);
                    element.value = campos[campo];
                    element.classList.add('is-valid');
                    
                    // Remove a classe após 3 segundos
                    setTimeout(() => {
                        element.classList.remove('is-valid');
                    }, 3000);
                }
                
                // Foca no campo número
                document.getElementById('numero').focus();
                
                // Mostra mensagem de sucesso
                const Toast = Swal.mixin({
                    toast: true,
                    position: 'top-end',
                    showConfirmButton: false,
                    timer: 3000,
                    timerProgressBar: true
                });
                
                Toast.fire({
                    icon: 'success',
                    title: 'Endereço encontrado!'
                });
            })
            .catch(error => {
                // Remove loading
                cepInput.classList.remove('cep-loading');
                cepInput.disabled = false;
                
                console.error('Erro ao buscar CEP:', error);
                Swal.fire({
                    title: 'Erro',
                    text: 'Erro ao buscar CEP. Verifique sua conexão e tente novamente.',
                    icon: 'error',
                    confirmButtonText: 'OK'
                });
            });
    }

    // Busca automática quando digitar 8 dígitos
    document.getElementById('cep').addEventListener('input', function(e) {
        const cep = this.value.replace(/\D/g, '');
        
        // Limpa timeout anterior
        if (cepTimeout) {
            clearTimeout(cepTimeout);
        }
        
        // Se tiver exatamente 8 dígitos, busca automaticamente após um pequeno delay
        if (cep.length === 8) {
            cepTimeout = setTimeout(() => {
                buscarCEP(false); // false para não mostrar aviso se não tiver 8 dígitos
            }, 500); // Aguarda 500ms após parar de digitar
        }
    });

    // Busca automática quando colar um CEP
    document.getElementById('cep').addEventListener('paste', function(e) {
        setTimeout(() => {
            const cep = this.value.replace(/\D/g, '');
            if (cep.length === 8) {
                buscarCEP(false);
            }
        }, 100); // Pequeno delay para garantir que o valor foi colado
    });

    // Enter no campo CEP busca manualmente
    document.getElementById('cep').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            e.preventDefault();
            buscarCEP(true); // true para mostrar avisos
        }
    });

    // Adicionar dependente
    function adicionarDependente() {
        const template = `
            <div class="dependente-card" data-index="${dependenteIndex}">
                <div class="dependente-header">
                    <span class="dependente-number">Dependente #${dependenteIndex + 1}</span>
                    <button type="button" class="btn-remove-dependente" onclick="removerDependente(this)">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
                <div class="form-grid">
                    <div class="form-group">
                        <label class="form-label">Nome Completo</label>
                        <input type="text" class="form-control" name="dependentes[${dependenteIndex}][nome]" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Data de Nascimento</label>
                        <input type="date" class="form-control" name="dependentes[${dependenteIndex}][data_nascimento]" required>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Parentesco</label>
                        <select class="form-select" name="dependentes[${dependenteIndex}][parentesco]" required>
                            <option value="">Selecione...</option>
                            <option value="Cônjuge">Cônjuge</option>
                            <option value="Filho(a)">Filho(a)</option>
                            <option value="Pai">Pai</option>
                            <option value="Mãe">Mãe</option>
                            <option value="Avô/Avó">Avô/Avó</option>
                            <option value="Outro">Outro</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="form-label">Sexo</label>
                        <select class="form-select" name="dependentes[${dependenteIndex}][sexo]" required>
                            <option value="">Selecione...</option>
                            <option value="Masculino">Masculino</option>
                            <option value="Feminino">Feminino</option>
                        </select>
                    </div>
                </div>
            </div>
        `;

        document.getElementById('dependentesContainer').insertAdjacentHTML('beforeend', template);
        dependenteIndex++;
        
        // Anima o novo card
        const newCard = document.querySelector(`[data-index="${dependenteIndex - 1}"]`);
        newCard.style.opacity = '0';
        setTimeout(() => {
            newCard.style.transition = 'opacity 0.3s ease';
            newCard.style.opacity = '1';
        }, 10);
    }

    // Remover dependente
    function removerDependente(button) {
        Swal.fire({
            title: 'Confirmar exclusão',
            text: 'Deseja remover este dependente?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Sim, remover',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                const card = button.closest('.dependente-card');
                card.style.transition = 'all 0.3s ease';
                card.style.opacity = '0';
                card.style.transform = 'translateX(50px)';
                
                setTimeout(() => {
                    card.remove();
                    // Renumera os dependentes
                    document.querySelectorAll('.dependente-number').forEach((el, idx) => {
                        el.textContent = `Dependente #${idx + 1}`;
                    });
                }, 300);
            }
        });
    }

    // Calcular valores dos serviços
    function calcularServicos() {
        const tipoAssociado = document.getElementById('tipoAssociado').value;
        const servicoJuridico = document.getElementById('servicoJuridico')?.checked || false;
        
        let valorSocial = 0;
        let valorJuridico = servicoJuridico ? VALOR_SERVICO_JURIDICO : 0;
        
        // Calcula valor do serviço social baseado no tipo
        switch(tipoAssociado) {
            case 'Contribuinte':
                valorSocial = VALOR_SERVICO_SOCIAL; // 100%
                break;
            case 'Agregado':
                valorSocial = VALOR_SERVICO_SOCIAL * 0.5; // 50%
                break;
            case 'Remido 50%':
                valorSocial = VALOR_SERVICO_SOCIAL * 0.5; // 50%
                break;
            case 'Benemerito':
            case 'Remido':
                valorSocial = 0; // Isento
                break;
        }
        
        // Atualiza os valores na tela
        document.getElementById('resumoTipo').textContent = tipoAssociado || '-';
        document.getElementById('resumoSocial').textContent = `R$ ${valorSocial.toFixed(2).replace('.', ',')}`;
        document.getElementById('resumoJuridico').textContent = `R$ ${valorJuridico.toFixed(2).replace('.', ',')}`;
        document.getElementById('totalMensal').textContent = `Total Mensal: R$ ${(valorSocial + valorJuridico).toFixed(2).replace('.', ',')}`;
    }

    // Validação do formulário
    function initFormValidation() {
        const form = document.getElementById('formAssociado');
        
        form.addEventListener('submit', function(e) {
            e.preventDefault();
            
            if (!validateForm()) {
                return;
            }
            
            salvarAssociado();
        });
        
        // Validação em tempo real
        const inputs = form.querySelectorAll('.form-control, .form-select');
        inputs.forEach(input => {
            input.addEventListener('blur', function() {
                validateField(this);
            });
        });
    }

    // Valida campo individual
    function validateField(field) {
        // Remove classes anteriores
        field.classList.remove('is-invalid', 'is-valid');
        
        // Validações específicas
        if (field.required && !field.value.trim()) {
            field.classList.add('is-invalid');
            return false;
        }
        
        // CPF
        if (field.id === 'cpf' && field.value) {
            if (!validarCPF(field.value)) {
                field.classList.add('is-invalid');
                return false;
            }
        }
        
        // Email
        if (field.type === 'email' && field.value) {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(field.value)) {
                field.classList.add('is-invalid');
                return false;
            }
        }
        
        // Se passou nas validações
        if (field.value.trim()) {
            field.classList.add('is-valid');
        }
        
        return true;
    }

    // Valida todo o formulário
    function validateForm() {
        const form = document.getElementById('formAssociado');
        const inputs = form.querySelectorAll('.form-control, .form-select');
        let isValid = true;
        
        inputs.forEach(input => {
            if (!validateField(input)) {
                isValid = false;
            }
        });
        
        if (!isValid) {
            Swal.fire('Atenção', 'Por favor, preencha todos os campos obrigatórios corretamente', 'warning');
        }
        
        return isValid;
    }

    // Valida CPF
    function validarCPF(cpf) {
        cpf = cpf.replace(/[^\d]+/g, '');
        
        if (cpf.length !== 11) return false;
        
        // Elimina CPFs conhecidos inválidos
        if (/^(\d)\1{10}$/.test(cpf)) return false;
        
        // Valida dígitos verificadores
        let soma = 0;
        let resto;
        
        for (let i = 1; i <= 9; i++) {
            soma += parseInt(cpf.substring(i - 1, i)) * (11 - i);
        }
        
        resto = (soma * 10) % 11;
        if (resto === 10 || resto === 11) resto = 0;
        if (resto !== parseInt(cpf.substring(9, 10))) return false;
        
        soma = 0;
        for (let i = 1; i <= 10; i++) {
            soma += parseInt(cpf.substring(i - 1, i)) * (12 - i);
        }
        
        resto = (soma * 10) % 11;
        if (resto === 10 || resto === 11) resto = 0;
        if (resto !== parseInt(cpf.substring(10, 11))) return false;
        
        return true;
    }

    // Salvar associado
    function salvarAssociado() {
        showLoading();
        
        const form = document.getElementById('formAssociado');
        const formData = new FormData(form);
        
        // Adiciona ação
        formData.append('action', '<?php echo $isEdicao ? 'update' : 'create'; ?>');
        
        fetch('../php/salvar_associado.php', {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            hideLoading();
            
            if (data.status === 'success') {
                Swal.fire({
                    title: 'Sucesso!',
                    text: data.message,
                    icon: 'success',
                    confirmButtonText: 'OK'
                }).then(() => {
                    window.location.href = 'index.php';
                });
            } else {
                Swal.fire('Erro', data.message || 'Erro ao salvar associado', 'error');
            }
        })
        .catch(error => {
            hideLoading();
            console.error('Erro:', error);
            Swal.fire('Erro', 'Erro ao processar solicitação', 'error');
        });
    }

    // Salvar rascunho
    function salvarRascunho() {
        // Implementar salvamento em localStorage
        const form = document.getElementById('formAssociado');
        const formData = new FormData(form);
        const data = {};
        
        for (let [key, value] of formData.entries()) {
            data[key] = value;
        }
        
        localStorage.setItem('rascunho_associado', JSON.stringify(data));
        
        Swal.fire({
            title: 'Rascunho salvo!',
            text: 'Os dados foram salvos localmente',
            icon: 'success',
            timer: 2000,
            showConfirmButton: false
        });
    }

    // Confirmar cancelamento
    function confirmarCancelamento() {
        Swal.fire({
            title: 'Confirmar cancelamento',
            text: 'Todas as alterações não salvas serão perdidas. Deseja continuar?',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Sim, cancelar',
            cancelButtonText: 'Continuar editando'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = 'index.php';
            }
        });
    }

    // Progress steps animation
    function updateProgressSteps(currentStep) {
        const steps = document.querySelectorAll('.step');
        
        steps.forEach((step, index) => {
            const stepNumber = index + 1;
            
            if (stepNumber < currentStep) {
                step.classList.add('completed');
                step.classList.remove('active');
            } else if (stepNumber === currentStep) {
                step.classList.add('active');
                step.classList.remove('completed');
            } else {
                step.classList.remove('active', 'completed');
            }
        });
    }

    // Mensagem final
    console.log('Formulário de cadastro inicializado com API de CEP, Serviços e Autocomplete');

    // Função de debug para verificar valores dos selects
    window.debugSelects = function() {
        console.log('=== DEBUG SELECTS ===');
        const selects = ['estadoCivil', 'escolaridade', 'corporacao', 'tipoAssociado', 'situacao', 'categoria', 'situacaoFinanceira', 'localDebito'];
        
        selects.forEach(id => {
            const element = document.getElementById(id);
            if (element) {
                console.log(`${id}:`, {
                    valor: element.value,
                    opcaoSelecionada: element.options[element.selectedIndex]?.text || 'Nenhuma',
                    todasOpcoes: Array.from(element.options).map(opt => ({
                        value: opt.value,
                        text: opt.text,
                        selected: opt.selected
                    }))
                });
            }
        });
        console.log('====================');
    };

    // Autocomplete para campo "Indicado por"
    function initIndicacaoAutocomplete() {
        const input = document.getElementById('indicacao');
        const suggestions = document.getElementById('indicacaoSuggestions');
        
        // Busca sugestões ao digitar
        input.addEventListener('input', function() {
            const query = this.value.trim();
            
            // Limpa timeout anterior
            if (indicacaoTimeout) {
                clearTimeout(indicacaoTimeout);
            }
            
            // Se tiver menos de 2 caracteres, esconde sugestões
            if (query.length < 2) {
                suggestions.classList.remove('show');
                selectedSuggestionIndex = -1;
                return;
            }
            
            // Mostra loading
            suggestions.innerHTML = `
                <div class="autocomplete-loading">
                    <i class="fas fa-spinner"></i> Buscando...
                </div>
            `;
            suggestions.classList.add('show');
            
            // Debounce de 300ms
            indicacaoTimeout = setTimeout(() => {
                buscarIndicadores(query);
            }, 300);
        });
        
        // Mostra indicadores populares ao focar no campo vazio
        input.addEventListener('focus', function() {
            if (this.value.trim().length === 0) {
                // Mostra loading
                suggestions.innerHTML = `
                    <div class="autocomplete-loading">
                        <i class="fas fa-spinner"></i> Carregando indicadores populares...
                    </div>
                `;
                suggestions.classList.add('show');
                
                // Busca os mais populares
                buscarIndicadores('', true);
            }
        });
        
        // Navegação por teclado
        input.addEventListener('keydown', function(e) {
            const items = suggestions.querySelectorAll('.autocomplete-item');
            
            if (e.key === 'ArrowDown') {
                e.preventDefault();
                selectedSuggestionIndex = Math.min(selectedSuggestionIndex + 1, items.length - 1);
                updateSelectedSuggestion(items);
            } else if (e.key === 'ArrowUp') {
                e.preventDefault();
                selectedSuggestionIndex = Math.max(selectedSuggestionIndex - 1, -1);
                updateSelectedSuggestion(items);
            } else if (e.key === 'Enter') {
                e.preventDefault();
                if (selectedSuggestionIndex >= 0 && items[selectedSuggestionIndex]) {
                    const selectedItem = items[selectedSuggestionIndex];
                    input.value = selectedItem.getAttribute('data-value');
                    suggestions.classList.remove('show');
                    selectedSuggestionIndex = -1;
                }
            } else if (e.key === 'Escape') {
                suggestions.classList.remove('show');
                selectedSuggestionIndex = -1;
            }
        });
        
        // Fecha sugestões ao clicar fora
        document.addEventListener('click', function(e) {
            if (!input.contains(e.target) && !suggestions.contains(e.target)) {
                suggestions.classList.remove('show');
                selectedSuggestionIndex = -1;
            }
        });
    }
    
    // Buscar indicadores no banco
    function buscarIndicadores(query, showPopular = false) {
        const suggestions = document.getElementById('indicacaoSuggestions');
        
        // Monta a URL com parâmetros apropriados
        let url = `../php/buscar_indicadores.php`;
        if (showPopular) {
            url += `?popular=1`;
        } else {
            url += `?q=${encodeURIComponent(query)}`;
        }
        
        fetch(url)
            .then(response => {
                if (!response.ok) {
                    throw new Error('Erro na requisição');
                }
                return response.json();
            })
            .then(data => {
                if (!data || data.length === 0) {
                    if (showPopular) {
                        suggestions.innerHTML = `
                            <div class="autocomplete-empty">
                                <i class="fas fa-info-circle"></i> Nenhum indicador cadastrado ainda
                            </div>
                        `;
                    } else {
                        suggestions.innerHTML = `
                            <div class="autocomplete-empty">
                                <i class="fas fa-user-plus"></i> Novo indicador: "${query}"
                            </div>
                        `;
                    }
                } else {
                    let headerHtml = '';
                    if (showPopular) {
                        headerHtml = `
                            <div style="padding: 0.5rem 1rem; background: var(--gray-100); font-size: 0.75rem; color: var(--gray-600); font-weight: 600;">
                                <i class="fas fa-star"></i> INDICADORES MAIS FREQUENTES
                            </div>
                        `;
                    }
                    
                    suggestions.innerHTML = headerHtml + data.map((item, index) => {
                        let highlightedName = item.nome;
                        
                        // Só destaca se não for busca popular
                        if (!showPopular && query) {
                            const regex = new RegExp(`(${query})`, 'gi');
                            highlightedName = item.nome.replace(regex, '<strong>$1</strong>');
                        }
                        
                        return `
                            <div class="autocomplete-item" 
                                 data-value="${item.nome}"
                                 data-index="${index}">
                                <i class="fas fa-user"></i>
                                <span>${highlightedName}</span>
                                ${item.count > 5 ? '<i class="fas fa-fire" style="color: var(--warning); margin-left: 0.5rem;" title="Indicador popular"></i>' : ''}
                                ${item.count > 1 ? `<small style="margin-left: auto; color: var(--gray-500);">(${item.count} indicações)</small>` : ''}
                            </div>
                        `;
                    }).join('');
                    
                    // Adiciona eventos de clique
                    suggestions.querySelectorAll('.autocomplete-item').forEach(item => {
                        item.addEventListener('click', function() {
                            document.getElementById('indicacao').value = this.getAttribute('data-value');
                            suggestions.classList.remove('show');
                            selectedSuggestionIndex = -1;
                        });
                    });
                }
            })
            .catch(error => {
                console.error('Erro ao buscar indicadores:', error);
                // Se der erro, permite digitar livremente
                if (!showPopular) {
                    suggestions.innerHTML = `
                        <div class="autocomplete-empty">
                            <i class="fas fa-user-plus"></i> Novo indicador: "${query}"
                        </div>
                    `;
                } else {
                    suggestions.classList.remove('show');
                }
            });
    }
    
    // Atualiza item selecionado na navegação por teclado
    function updateSelectedSuggestion(items) {
        items.forEach((item, index) => {
            if (index === selectedSuggestionIndex) {
                item.classList.add('active');
                item.scrollIntoView({ block: 'nearest' });
            } else {
                item.classList.remove('active');
            }
        });
    }
    
    // Inicializa autocomplete
    initIndicacaoAutocomplete();
    </script>
</body>
</html>